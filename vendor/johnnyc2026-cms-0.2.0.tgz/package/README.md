# CMS Convex Component

A reusable [Convex component](https://docs.convex.dev/components) compiled from
17 Port CMS blueprints (every blueprint whose identifier starts with `cms_`).
It carries the CMS data model — schema, validators, relations, calculations,
mirrors, and aggregations — as installable Convex code. It carries **no**
authentication, identity, or third-party integrations: those belong to the host
(parent) app.

- Component name: `cms` (see `src/component/convex.config.ts`)
- Source model: `model/model.ir.json` (normalized IR), raw export `model/port.raw.json`
- Generation is deterministic: re-running the generator scripts byte-reproduces
  `src/`, `model/`, and `tests/`

## Architecture

Component functions are **never** called by browser clients directly. They are
visible to the host app as internal function references; the host wraps them
with authentication, tenant resolution, and permissions.

```
React/Website
  -> HOST Convex functions (auth / tenant / permissions live here)
  -> ctx.runQuery / ctx.runMutation  (via the Cms wrapper, src/client.ts)
  -> components.cms.*                (internal function references)
  -> CMS component
```

## Layout

```
src/component/            # the installable component
  convex.config.ts        # defineComponent("cms")
  schema.ts               # 17 tables, stable Port identifiers as table names
  validators.ts           # per-blueprint v.object validators
  relations.ts            # relation metadata + read-time traversal helpers
  calculations.ts         # 9 JQ-derived calculations (formula kept in comments)
  projections.ts          # mirror + aggregation resolvers (read-time)
  scorecards.ts           # reports definition_missing — no scorecard rules in source
  records/<blueprint>.ts  # create / get / list / update per blueprint (17 modules)
  _generated/             # codegen output (template-faithful; real codegen overwrites)
src/client.ts             # host-side Cms wrapper (REGENERATED — see below)
src/shared/types.ts       # shared host/component types
examples/host-cms-facade.ts  # copy-paste host convex/cms.ts example (auth-gated)
model/                    # model artifacts: port.raw.json, model.ir.json,
                          # source-gaps.json, gen-stats.json
tests/parity.mjs          # JQ parity test (see VERIFICATION.md)
```

## Install

1. Install the package — either from an npm tarball:
   ```bash
   npm pack   # produces johnny-cms-<version>.tgz
   ```
   or copy this package into your Convex app, e.g. `components/cms/`
   (or at minimum `src/` + `model/`).
2. `src/component/_generated/` ships template-faithful codegen output
   (`server.ts`/`dataModel.ts` verbatim, `api.ts` generated from the module
   list, `component.ts` as the structural equivalent — see VERIFICATION.md
   Tier 3). The first authenticated `npx convex dev` (or
   `npx convex codegen --component-dir ./src/component`) overwrites it with
   backend-analyzed output; nothing blocks that.
3. Register the component in your app:

```ts
// convex/convex.config.ts (host app)
import { defineApp } from "convex/server";
import cms from "../components/cms/src/component/convex.config.js";

const app = defineApp();
app.use(cms);
export default app;
```

(When installed as an npm package, import the config from
`@johnny/cms/convex.config.js` instead.)

## Usage

4. Build the typed wrapper once per host module from the mounted component
   reference, then call it from auth-gated host functions:

```ts
// convex/cms.ts (host app)
import { components } from "./_generated/api";
import { Cms } from "@johnny/cms";

const cms = new Cms(components.cms);

export const createSite = mutation({
  args: { identifier: v.string(), properties: v.any() /* ... */ },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("unauthenticated");
    // record ids cross the boundary as opaque strings
    return await cms.site.create(ctx, args);
  },
});
```

See `examples/host-cms-facade.ts` for a complete copy-paste-ready
`convex/cms.ts` (`createSite` / `getSite` / `listSites` / `updateSite`, each
auth-gated before delegating).

The wrapper exposes one namespace per table — `actor`, `asset`,
`assetVariant`, `contentEntry`, `contentReference`, `contentType`,
`entryTaxonomy`, `fieldDefinition`, `navigation`, `navigationItem`,
`publication`, `redirect`, `revision`, `site`, `taxonomy`, `taxonomyTerm`,
`workflowLog` — each with `create` / `get` / `list` / `update` methods whose
argument and return types are exactly the component's validators
(`FunctionArgs` / `FunctionReturnType` of each component function). `create`
and `update` run through `ctx.runMutation`; `get` and `list` through
`ctx.runQuery`.

Package entry points (`package.json` `exports`):

| Import | Resolves to | Provides |
|---|---|---|
| `@johnny/cms` / `@johnny/cms/client` | `./src/client.ts` | `Cms`, `CmsComponent`, `CmsQueryRunner`, `CmsMutationRunner`, per-table namespaces |
| `@johnny/cms/convex.config.js` | `./src/component/convex.config.ts` | `defineComponent("cms")` for `app.use(...)` |
| `@johnny/cms/_generated/component.js` | `./src/component/_generated/component.ts` | `ComponentApi` type |

## Regeneration

The component is generated, not hand-written. To regenerate after the Port
export changes:

```bash
python3 ~/workspace/port-export/cms_gen_part1.py  # Port JSON -> model/model.ir.json
python3 ~/workspace/port-export/cms_gen_part2.py  # IR -> core component files
python3 ~/workspace/port-export/cms_gen_part3.py  # IR -> records/* + client + docs
```

Re-running all three must byte-reproduce the output (verified 2026-09-24 —
see VERIFICATION.md). Hand edits inside `src/component/` will be overwritten.

`src/client.ts` is regenerated separately from the records modules (it is
host-side code, not component code):

```bash
python3 ~/workspace/cms-0.2.0-upgrade/gen_client.py
```

## Source gaps (16) — what was NOT invented

The generator refuses to invent what Port did not supply. Every gap is listed
in `model/source-gaps.json` with the file it blocks:

| Kind | Count | Behavior |
|---|---|---|
| `unshaped_object` | 9 | Object properties with no nested shape evidence → `v.any()` |
| `missing_array_items` | 5 | Arrays with no source `items` schema → `v.array(v.any())` |
| `missing_scorecard_rules` | 1 | No CMS scorecard definitions/rules in the export → `scorecards.ts` reports `definition_missing` |
| `missing_workflow_behavior` | 1 | `cms_workflow_log` is a log-record blueprint only; no trigger/input/behavior definitions → no workflow policy invented |

Related runtime behavior:

- **Mirrors** resolve at read time via `resolveMirror()` (multi-hop paths
  supported). A missing relation target or empty path returns
  `{ status: "unresolved", reason }` — never an invented value.
- **Aggregations** are indexed bounded counts via `resolveAggregation()`.
  Over-limit scans return `{ status: "incomplete" }` instead of silently
  truncating.
- **Calculations** preserve the original JQ formula in a comment above each
  TypeScript implementation, including jq's exact null semantics
  (`null | tostring` → `"null"`, `null + "x"` → `"x"`). Parity-tested against
  the real `jq` binary: 30/30 fixtures pass (`tests/parity.mjs`).

## What the host app owns

- **Auth/identity**: the component exposes public `create/get/list/update`
  functions with no auth checks. Gate them in the host (e.g. Clerk, per the
  project default) before exposing to clients.
- **Integrations**: no webhooks, no external APIs, no scheduled jobs.
- **Scorecards/workflows**: intentionally inert until real Port
  scorecard rules / workflow definitions are supplied and regenerated in.

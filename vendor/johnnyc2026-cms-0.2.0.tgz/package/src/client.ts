/**
 * Host-side typed wrapper for the @johnny/cms Convex component.
 *
 * This file runs in HOST Convex functions (never in the browser). The host app
 * mounts the component (see README.md), then constructs one wrapper:
 *
 *   import { components } from "./_generated/api";
 *   import { Cms } from "@johnny/cms";
 *
 *   const cms = new Cms(components.cms);
 *   await cms.site.create(ctx, { identifier, properties });
 *
 * Boundary (see the Convex component authoring contract):
 * - Component functions are NOT exposed to browser clients. They are visible
 *   to the host as internal function references; the host calls them with
 *   ctx.runQuery / ctx.runMutation and wraps them with auth, tenant
 *   resolution, and permissions (see examples/host-cms-facade.ts).
 * - Component record IDs cross the boundary as opaque strings.
 *
 * Typing note: src/component/_generated/component.ts currently ships the
 * template-faithful ComponentApi stand-in (= typeof internal), which does not
 * yet carry the public records tree; the first authenticated
 * `npx convex codegen --component-dir ./src/component` overwrites it with the
 * inlined component exports tree (nested `records.<module>.<op>` references).
 * `RecordsTree` below resolves against ComponentApi when it carries the tree
 * and falls back to the component's public `api` tree otherwise — the two
 * agree on every validator, so argument and return types are identical either
 * way. After real codegen the wrapper adopts the inlined tree automatically.
 *
 * REGENERATED — do not hand-edit. Regenerate with:
 *   python3 ~/workspace/cms-0.2.0-upgrade/gen_client.py
 */
import type { api } from "./component/_generated/api";
import type { ComponentApi } from "./component/_generated/component";
import type {
  AnyDataModel,
  FunctionArgs,
  FunctionReturnType,
  GenericMutationCtx,
  GenericQueryCtx,
} from "convex/server";

/**
 * The type of the host's `components.cms` reference.
 */
export type CmsComponent = ComponentApi;

/**
 * Minimal host-context capabilities the wrapper needs. The host's own
 * QueryCtx / MutationCtx / ActionCtx are structurally assignable: `runQuery`
 * and `runMutation` do not depend on the host data model.
 */
export type CmsQueryRunner = Pick<GenericQueryCtx<AnyDataModel>, "runQuery">;
export type CmsMutationRunner = Pick<
  GenericMutationCtx<AnyDataModel>,
  "runQuery" | "runMutation"
>;

/**
 * The component's per-module records tree. Prefers the records tree carried
 * by ComponentApi (present after real codegen); falls back to the component's
 * public `api` tree while the template-faithful stand-in is in place.
 */
type RecordsTree = ComponentApi extends { records: infer R }
  ? R
  : (typeof api)["records"];

/** Typed host-side access to the `cms_actor` records module. */
export class ActorNamespace {
  constructor(private readonly refs: RecordsTree["cms_actor"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_actor"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_actor"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_actor"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_actor"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_actor"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_actor"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_actor"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_actor"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_asset` records module. */
export class AssetNamespace {
  constructor(private readonly refs: RecordsTree["cms_asset"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_asset"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_asset"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_asset"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_asset"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_asset"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_asset"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_asset"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_asset"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_asset_variant` records module. */
export class AssetVariantNamespace {
  constructor(private readonly refs: RecordsTree["cms_asset_variant"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_asset_variant"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_asset_variant"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_asset_variant"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_asset_variant"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_asset_variant"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_asset_variant"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_asset_variant"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_asset_variant"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_content_entry` records module. */
export class ContentEntryNamespace {
  constructor(private readonly refs: RecordsTree["cms_content_entry"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_content_entry"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_entry"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_content_entry"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_entry"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_content_entry"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_entry"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_content_entry"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_entry"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_content_reference` records module. */
export class ContentReferenceNamespace {
  constructor(private readonly refs: RecordsTree["cms_content_reference"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_content_reference"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_reference"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_content_reference"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_reference"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_content_reference"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_reference"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_content_reference"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_reference"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_content_type` records module. */
export class ContentTypeNamespace {
  constructor(private readonly refs: RecordsTree["cms_content_type"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_content_type"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_type"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_content_type"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_type"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_content_type"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_type"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_content_type"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_content_type"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_entry_taxonomy` records module. */
export class EntryTaxonomyNamespace {
  constructor(private readonly refs: RecordsTree["cms_entry_taxonomy"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_entry_taxonomy"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_entry_taxonomy"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_entry_taxonomy"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_entry_taxonomy"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_entry_taxonomy"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_entry_taxonomy"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_entry_taxonomy"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_entry_taxonomy"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_field_definition` records module. */
export class FieldDefinitionNamespace {
  constructor(private readonly refs: RecordsTree["cms_field_definition"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_field_definition"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_field_definition"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_field_definition"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_field_definition"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_field_definition"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_field_definition"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_field_definition"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_field_definition"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_navigation` records module. */
export class NavigationNamespace {
  constructor(private readonly refs: RecordsTree["cms_navigation"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_navigation"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_navigation"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_navigation"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_navigation"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_navigation"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_navigation"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_navigation"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_navigation"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_navigation_item` records module. */
export class NavigationItemNamespace {
  constructor(private readonly refs: RecordsTree["cms_navigation_item"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_navigation_item"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_navigation_item"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_navigation_item"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_navigation_item"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_navigation_item"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_navigation_item"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_navigation_item"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_navigation_item"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_publication` records module. */
export class PublicationNamespace {
  constructor(private readonly refs: RecordsTree["cms_publication"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_publication"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_publication"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_publication"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_publication"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_publication"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_publication"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_publication"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_publication"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_redirect` records module. */
export class RedirectNamespace {
  constructor(private readonly refs: RecordsTree["cms_redirect"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_redirect"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_redirect"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_redirect"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_redirect"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_redirect"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_redirect"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_redirect"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_redirect"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_revision` records module. */
export class RevisionNamespace {
  constructor(private readonly refs: RecordsTree["cms_revision"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_revision"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_revision"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_revision"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_revision"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_revision"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_revision"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_revision"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_revision"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_site` records module. */
export class SiteNamespace {
  constructor(private readonly refs: RecordsTree["cms_site"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_site"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_site"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_site"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_site"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_site"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_site"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_site"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_site"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_taxonomy` records module. */
export class TaxonomyNamespace {
  constructor(private readonly refs: RecordsTree["cms_taxonomy"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_taxonomy"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_taxonomy"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_taxonomy"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_taxonomy"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_taxonomy"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_taxonomy"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_taxonomy"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_taxonomy"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_taxonomy_term` records module. */
export class TaxonomyTermNamespace {
  constructor(private readonly refs: RecordsTree["cms_taxonomy_term"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_taxonomy_term"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_taxonomy_term"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_taxonomy_term"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_taxonomy_term"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_taxonomy_term"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_taxonomy_term"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_taxonomy_term"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_taxonomy_term"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/** Typed host-side access to the `cms_workflow_log` records module. */
export class WorkflowLogNamespace {
  constructor(private readonly refs: RecordsTree["cms_workflow_log"]) {}

  create(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_workflow_log"]["create"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_workflow_log"]["create"]>> {
    return ctx.runMutation(this.refs.create, args);
  }

  get(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_workflow_log"]["get"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_workflow_log"]["get"]>> {
    return ctx.runQuery(this.refs.get, args);
  }

  list(
    ctx: CmsQueryRunner,
    args: FunctionArgs<RecordsTree["cms_workflow_log"]["list"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_workflow_log"]["list"]>> {
    return ctx.runQuery(this.refs.list, args);
  }

  update(
    ctx: CmsMutationRunner,
    args: FunctionArgs<RecordsTree["cms_workflow_log"]["update"]>,
  ): Promise<FunctionReturnType<RecordsTree["cms_workflow_log"]["update"]>> {
    return ctx.runMutation(this.refs.update, args);
  }

}

/**
 * Host-side client for the cms component.
 *
 * Construct once per host module from the mounted component reference:
 * `const cms = new Cms(components.cms);` then call e.g.
 * `cms.site.create(ctx, args)` inside auth-gated host functions.
 */
export class Cms {
  readonly actor: ActorNamespace;
  readonly asset: AssetNamespace;
  readonly assetVariant: AssetVariantNamespace;
  readonly contentEntry: ContentEntryNamespace;
  readonly contentReference: ContentReferenceNamespace;
  readonly contentType: ContentTypeNamespace;
  readonly entryTaxonomy: EntryTaxonomyNamespace;
  readonly fieldDefinition: FieldDefinitionNamespace;
  readonly navigation: NavigationNamespace;
  readonly navigationItem: NavigationItemNamespace;
  readonly publication: PublicationNamespace;
  readonly redirect: RedirectNamespace;
  readonly revision: RevisionNamespace;
  readonly site: SiteNamespace;
  readonly taxonomy: TaxonomyNamespace;
  readonly taxonomyTerm: TaxonomyTermNamespace;
  readonly workflowLog: WorkflowLogNamespace;
  /**
   * @param component the host's `components.cms` reference. The
   *   intersection requires the records tree the wrapper delegates to;
   *   the mounted component always satisfies it at runtime, and the
   *   real codegen-inlined ComponentApi carries it in the type.
   */
  constructor(component: ComponentApi & { records: RecordsTree }) {
    this.actor = new ActorNamespace(component.records.cms_actor);
    this.asset = new AssetNamespace(component.records.cms_asset);
    this.assetVariant = new AssetVariantNamespace(component.records.cms_asset_variant);
    this.contentEntry = new ContentEntryNamespace(component.records.cms_content_entry);
    this.contentReference = new ContentReferenceNamespace(component.records.cms_content_reference);
    this.contentType = new ContentTypeNamespace(component.records.cms_content_type);
    this.entryTaxonomy = new EntryTaxonomyNamespace(component.records.cms_entry_taxonomy);
    this.fieldDefinition = new FieldDefinitionNamespace(component.records.cms_field_definition);
    this.navigation = new NavigationNamespace(component.records.cms_navigation);
    this.navigationItem = new NavigationItemNamespace(component.records.cms_navigation_item);
    this.publication = new PublicationNamespace(component.records.cms_publication);
    this.redirect = new RedirectNamespace(component.records.cms_redirect);
    this.revision = new RevisionNamespace(component.records.cms_revision);
    this.site = new SiteNamespace(component.records.cms_site);
    this.taxonomy = new TaxonomyNamespace(component.records.cms_taxonomy);
    this.taxonomyTerm = new TaxonomyTermNamespace(component.records.cms_taxonomy_term);
    this.workflowLog = new WorkflowLogNamespace(component.records.cms_workflow_log);
  }
}

// GENERATED — shared TypeScript types for the cms component.
import type { Infer, GenericId } from "convex/values";
import type {
  cmsActorPropertiesValidator,
  cmsAssetPropertiesValidator,
  cmsAssetVariantPropertiesValidator,
  cmsContentEntryPropertiesValidator,
  cmsContentReferencePropertiesValidator,
  cmsContentTypePropertiesValidator,
  cmsEntryTaxonomyPropertiesValidator,
  cmsFieldDefinitionPropertiesValidator,
  cmsNavigationPropertiesValidator,
  cmsNavigationItemPropertiesValidator,
  cmsPublicationPropertiesValidator,
  cmsRedirectPropertiesValidator,
  cmsRevisionPropertiesValidator,
  cmsSitePropertiesValidator,
  cmsTaxonomyPropertiesValidator,
  cmsTaxonomyTermPropertiesValidator,
  cmsWorkflowLogPropertiesValidator,
  cmsActorRelationsValidator,
  cmsAssetRelationsValidator,
  cmsAssetVariantRelationsValidator,
  cmsContentEntryRelationsValidator,
  cmsContentReferenceRelationsValidator,
  cmsContentTypeRelationsValidator,
  cmsEntryTaxonomyRelationsValidator,
  cmsFieldDefinitionRelationsValidator,
  cmsNavigationRelationsValidator,
  cmsNavigationItemRelationsValidator,
  cmsPublicationRelationsValidator,
  cmsRedirectRelationsValidator,
  cmsRevisionRelationsValidator,
  cmsSiteRelationsValidator,
  cmsTaxonomyRelationsValidator,
  cmsTaxonomyTermRelationsValidator,
  cmsWorkflowLogRelationsValidator,
} from "../component/validators";

export type CmsActorProperties = Infer<typeof cmsActorPropertiesValidator>;
export type CmsActorRelations = Infer<typeof cmsActorRelationsValidator>;
export type CmsActorDoc = {
  _id: GenericId<"cms_actor">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsActorProperties;
  relations: CmsActorRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsAssetProperties = Infer<typeof cmsAssetPropertiesValidator>;
export type CmsAssetRelations = Infer<typeof cmsAssetRelationsValidator>;
export type CmsAssetDoc = {
  _id: GenericId<"cms_asset">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsAssetProperties;
  relations: CmsAssetRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsAssetVariantProperties = Infer<typeof cmsAssetVariantPropertiesValidator>;
export type CmsAssetVariantRelations = Infer<typeof cmsAssetVariantRelationsValidator>;
export type CmsAssetVariantDoc = {
  _id: GenericId<"cms_asset_variant">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsAssetVariantProperties;
  relations: CmsAssetVariantRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsContentEntryProperties = Infer<typeof cmsContentEntryPropertiesValidator>;
export type CmsContentEntryRelations = Infer<typeof cmsContentEntryRelationsValidator>;
export type CmsContentEntryDoc = {
  _id: GenericId<"cms_content_entry">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsContentEntryProperties;
  relations: CmsContentEntryRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsContentReferenceProperties = Infer<typeof cmsContentReferencePropertiesValidator>;
export type CmsContentReferenceRelations = Infer<typeof cmsContentReferenceRelationsValidator>;
export type CmsContentReferenceDoc = {
  _id: GenericId<"cms_content_reference">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsContentReferenceProperties;
  relations: CmsContentReferenceRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsContentTypeProperties = Infer<typeof cmsContentTypePropertiesValidator>;
export type CmsContentTypeRelations = Infer<typeof cmsContentTypeRelationsValidator>;
export type CmsContentTypeDoc = {
  _id: GenericId<"cms_content_type">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsContentTypeProperties;
  relations: CmsContentTypeRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsEntryTaxonomyProperties = Infer<typeof cmsEntryTaxonomyPropertiesValidator>;
export type CmsEntryTaxonomyRelations = Infer<typeof cmsEntryTaxonomyRelationsValidator>;
export type CmsEntryTaxonomyDoc = {
  _id: GenericId<"cms_entry_taxonomy">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsEntryTaxonomyProperties;
  relations: CmsEntryTaxonomyRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsFieldDefinitionProperties = Infer<typeof cmsFieldDefinitionPropertiesValidator>;
export type CmsFieldDefinitionRelations = Infer<typeof cmsFieldDefinitionRelationsValidator>;
export type CmsFieldDefinitionDoc = {
  _id: GenericId<"cms_field_definition">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsFieldDefinitionProperties;
  relations: CmsFieldDefinitionRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsNavigationProperties = Infer<typeof cmsNavigationPropertiesValidator>;
export type CmsNavigationRelations = Infer<typeof cmsNavigationRelationsValidator>;
export type CmsNavigationDoc = {
  _id: GenericId<"cms_navigation">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsNavigationProperties;
  relations: CmsNavigationRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsNavigationItemProperties = Infer<typeof cmsNavigationItemPropertiesValidator>;
export type CmsNavigationItemRelations = Infer<typeof cmsNavigationItemRelationsValidator>;
export type CmsNavigationItemDoc = {
  _id: GenericId<"cms_navigation_item">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsNavigationItemProperties;
  relations: CmsNavigationItemRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsPublicationProperties = Infer<typeof cmsPublicationPropertiesValidator>;
export type CmsPublicationRelations = Infer<typeof cmsPublicationRelationsValidator>;
export type CmsPublicationDoc = {
  _id: GenericId<"cms_publication">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsPublicationProperties;
  relations: CmsPublicationRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsRedirectProperties = Infer<typeof cmsRedirectPropertiesValidator>;
export type CmsRedirectRelations = Infer<typeof cmsRedirectRelationsValidator>;
export type CmsRedirectDoc = {
  _id: GenericId<"cms_redirect">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsRedirectProperties;
  relations: CmsRedirectRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsRevisionProperties = Infer<typeof cmsRevisionPropertiesValidator>;
export type CmsRevisionRelations = Infer<typeof cmsRevisionRelationsValidator>;
export type CmsRevisionDoc = {
  _id: GenericId<"cms_revision">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsRevisionProperties;
  relations: CmsRevisionRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsSiteProperties = Infer<typeof cmsSitePropertiesValidator>;
export type CmsSiteRelations = Infer<typeof cmsSiteRelationsValidator>;
export type CmsSiteDoc = {
  _id: GenericId<"cms_site">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsSiteProperties;
  relations: CmsSiteRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsTaxonomyProperties = Infer<typeof cmsTaxonomyPropertiesValidator>;
export type CmsTaxonomyRelations = Infer<typeof cmsTaxonomyRelationsValidator>;
export type CmsTaxonomyDoc = {
  _id: GenericId<"cms_taxonomy">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsTaxonomyProperties;
  relations: CmsTaxonomyRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsTaxonomyTermProperties = Infer<typeof cmsTaxonomyTermPropertiesValidator>;
export type CmsTaxonomyTermRelations = Infer<typeof cmsTaxonomyTermRelationsValidator>;
export type CmsTaxonomyTermDoc = {
  _id: GenericId<"cms_taxonomy_term">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsTaxonomyTermProperties;
  relations: CmsTaxonomyTermRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};
export type CmsWorkflowLogProperties = Infer<typeof cmsWorkflowLogPropertiesValidator>;
export type CmsWorkflowLogRelations = Infer<typeof cmsWorkflowLogRelationsValidator>;
export type CmsWorkflowLogDoc = {
  _id: GenericId<"cms_workflow_log">;
  _creationTime: number;
  identifier: string;
  title?: string;
  properties: CmsWorkflowLogProperties;
  relations: CmsWorkflowLogRelations;
  revision: number;
  sourceBlueprint: string;
  sourceUpdatedAt?: string;
};

export type CmsTableName = "cms_actor" | "cms_asset" | "cms_asset_variant" | "cms_content_entry" | "cms_content_reference" | "cms_content_type" | "cms_entry_taxonomy" | "cms_field_definition" | "cms_navigation" | "cms_navigation_item" | "cms_publication" | "cms_redirect" | "cms_revision" | "cms_site" | "cms_taxonomy" | "cms_taxonomy_term" | "cms_workflow_log";

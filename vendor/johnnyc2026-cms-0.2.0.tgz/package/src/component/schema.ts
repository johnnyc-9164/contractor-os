// GENERATED from Port cms_* blueprints — do not hand-edit.
// Regenerate with the port-to-convex-component skill.
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

// cms_actor — CMS Actor
const cmsActorTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    display_name: v.string(),
    email: v.string(),
    external_auth_id: v.string(),
    external_auth_provider: v.union(v.literal("betterauth"), v.literal("clerk"), v.literal("workos"), v.literal("custom")),
    role: v.union(v.literal("viewer"), v.literal("author"), v.literal("editor"), v.literal("publisher"), v.literal("administrator")),
    site_scope: v.optional(v.array(v.any())),
  }),
  relations: v.object({
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
;
// cms_asset — CMS Asset
const cmsAssetTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    alt_text: v.optional(v.string()),
    asset_type: v.union(v.literal("image"), v.literal("video"), v.literal("audio"), v.literal("document"), v.literal("file")),
    caption: v.optional(v.string()),
    checksum: v.string(),
    deleted_at: v.optional(v.string()),
    duration_seconds: v.optional(v.number()),
    filename: v.string(),
    height_px: v.optional(v.number()),
    metadata: v.optional(v.any()),
    mime_type: v.string(),
    size_bytes: v.number(),
    storage_key: v.string(),
    width_px: v.optional(v.number()),
  }),
  relations: v.object({
    site: v.optional(v.id("cms_site")),
    uploaded_by: v.optional(v.id("cms_actor")),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_site", ["relations.site"])
  .index("by_uploaded_by", ["relations.uploaded_by"])
;
// cms_asset_variant — CMS Asset Variant
const cmsAssetVariantTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    height_px: v.optional(v.number()),
    key: v.string(),
    mime_type: v.string(),
    size_bytes: v.number(),
    storage_key: v.string(),
    transform_config: v.any(),
    width_px: v.optional(v.number()),
  }),
  relations: v.object({
    asset: v.id("cms_asset"),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_asset", ["relations.asset"])
;
// cms_content_entry — CMS Content Entry
const cmsContentEntryTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    archived_at: v.optional(v.string()),
    content_type_key: v.string(),
    data: v.optional(v.any()),
    deleted_at: v.optional(v.string()),
    locale: v.string(),
    published_at: v.optional(v.string()),
    scheduled_publish_at: v.optional(v.string()),
    scheduled_unpublish_at: v.optional(v.string()),
    seo_canonical_url: v.optional(v.string()),
    seo_meta_description: v.optional(v.string()),
    seo_robots: v.optional(v.union(v.literal("index_follow"), v.literal("index_nofollow"), v.literal("noindex_follow"), v.literal("noindex_nofollow"))),
    seo_sitemap_changefreq: v.optional(v.union(v.literal("always"), v.literal("hourly"), v.literal("daily"), v.literal("weekly"), v.literal("monthly"), v.literal("yearly"), v.literal("never"))),
    seo_sitemap_include: v.optional(v.boolean()),
    seo_sitemap_priority: v.optional(v.number()),
    seo_social_description: v.optional(v.string()),
    seo_social_title: v.optional(v.string()),
    seo_structured_data: v.optional(v.any()),
    seo_title: v.optional(v.string()),
    slug: v.string(),
    status: v.union(v.literal("draft"), v.literal("review"), v.literal("approved"), v.literal("scheduled"), v.literal("published"), v.literal("archived")),
    title: v.string(),
    translation_group_id: v.optional(v.string()),
  }),
  relations: v.object({
    author: v.optional(v.id("cms_actor")),
    site: v.id("cms_site"),
    content_type: v.id("cms_content_type"),
    last_editor: v.optional(v.id("cms_actor")),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_author", ["relations.author"])
  .index("by_site", ["relations.site"])
  .index("by_content_type", ["relations.content_type"])
  .index("by_last_editor", ["relations.last_editor"])
;
// cms_content_reference — CMS Content Reference
const cmsContentReferenceTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    target_type: v.union(v.literal("entry"), v.literal("asset"), v.literal("external")),
    source_field: v.optional(v.string()),
    external_entity_type: v.optional(v.string()),
    external_entity_id: v.optional(v.string()),
    external_component: v.optional(v.string()),
    display_order: v.optional(v.number()),
    context: v.optional(v.string()),
    created_at: v.string(),
  }),
  relations: v.object({
    source_entry: v.id("cms_content_entry"),
    target_asset: v.optional(v.id("cms_asset")),
    target_entry: v.optional(v.id("cms_content_entry")),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_source_entry", ["relations.source_entry"])
  .index("by_target_asset", ["relations.target_asset"])
  .index("by_target_entry", ["relations.target_entry"])
;
// cms_content_type — CMS Content Type
const cmsContentTypeTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    key: v.string(),
    name: v.string(),
    description: v.optional(v.string()),
    singleton: v.boolean(),
    enabled: v.boolean(),
    seo_enabled: v.optional(v.boolean()),
    revision_limit: v.optional(v.number()),
    icon_name: v.optional(v.string()),
  }),
  relations: v.object({
    site: v.optional(v.id("cms_site")),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_site", ["relations.site"])
;
// cms_entry_taxonomy — CMS Entry Taxonomy
const cmsEntryTaxonomyTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    assigned_at: v.string(),
  }),
  relations: v.object({
    entry: v.id("cms_content_entry"),
    term: v.id("cms_taxonomy_term"),
    assigned_by: v.optional(v.id("cms_actor")),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_entry", ["relations.entry"])
  .index("by_term", ["relations.term"])
  .index("by_assigned_by", ["relations.assigned_by"])
;
// cms_field_definition — CMS Field Definition
const cmsFieldDefinitionTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    allowed_values: v.optional(v.array(v.any())),
    default_value: v.optional(v.string()),
    description: v.optional(v.string()),
    field_type: v.union(v.literal("text"), v.literal("richText"), v.literal("number"), v.literal("boolean"), v.literal("date"), v.literal("datetime"), v.literal("select"), v.literal("multiSelect"), v.literal("slug"), v.literal("url"), v.literal("email"), v.literal("json"), v.literal("asset"), v.literal("assetList"), v.literal("reference"), v.literal("referenceList"), v.literal("object"), v.literal("objectList")),
    hidden: v.optional(v.boolean()),
    key: v.string(),
    label: v.string(),
    localized: v.optional(v.boolean()),
    max_length: v.optional(v.number()),
    max_value: v.optional(v.number()),
    min_length: v.optional(v.number()),
    min_value: v.optional(v.number()),
    order: v.number(),
    pattern: v.optional(v.string()),
    reference_target_types: v.optional(v.array(v.any())),
    required: v.boolean(),
    searchable: v.optional(v.boolean()),
    unique_field: v.optional(v.boolean()),
  }),
  relations: v.object({
    content_type: v.id("cms_content_type"),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_content_type", ["relations.content_type"])
;
// cms_navigation — CMS Navigation
const cmsNavigationTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    description: v.optional(v.string()),
    enabled: v.boolean(),
    key: v.string(),
    locale: v.optional(v.string()),
    name: v.string(),
  }),
  relations: v.object({
    site: v.id("cms_site"),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_site", ["relations.site"])
;
// cms_navigation_item — CMS Navigation Item
const cmsNavigationItemTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    label: v.string(),
    url: v.optional(v.string()),
    order: v.number(),
    target: v.union(v.literal("self"), v.literal("blank"), v.literal("parent"), v.literal("top")),
    visibility: v.union(v.literal("always"), v.literal("authenticated"), v.literal("unauthenticated"), v.literal("hidden")),
    is_broken: v.optional(v.boolean()),
    metadata: v.optional(v.any()),
  }),
  relations: v.object({
    navigation: v.id("cms_navigation"),
    entry: v.optional(v.id("cms_content_entry")),
    parent_item: v.optional(v.id("cms_navigation_item")),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_navigation", ["relations.navigation"])
  .index("by_entry", ["relations.entry"])
  .index("by_parent_item", ["relations.parent_item"])
;
// cms_publication — CMS Publication
const cmsPublicationTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    action: v.union(v.literal("publish"), v.literal("unpublish"), v.literal("schedule"), v.literal("cancel_schedule")),
    channel: v.optional(v.string()),
    published_at: v.string(),
    scheduled_for: v.optional(v.string()),
    note: v.optional(v.string()),
    revision_number: v.optional(v.number()),
    previous_revision_number: v.optional(v.number()),
  }),
  relations: v.object({
    published_by: v.optional(v.id("cms_actor")),
    entry: v.id("cms_content_entry"),
    site: v.id("cms_site"),
    previous_revision: v.optional(v.id("cms_revision")),
    revision: v.id("cms_revision"),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_published_by", ["relations.published_by"])
  .index("by_entry", ["relations.entry"])
  .index("by_site", ["relations.site"])
  .index("by_previous_revision", ["relations.previous_revision"])
  .index("by_revision", ["relations.revision"])
;
// cms_redirect — CMS Redirect
const cmsRedirectTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    source_path: v.string(),
    destination: v.optional(v.string()),
    status_code: v.union(v.literal("301"), v.literal("302"), v.literal("307"), v.literal("308"), v.literal("410")),
    enabled: v.boolean(),
    note: v.optional(v.string()),
  }),
  relations: v.object({
    site: v.id("cms_site"),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_site", ["relations.site"])
;
// cms_revision — CMS Revision
const cmsRevisionTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    revision_number: v.number(),
    data_snapshot: v.any(),
    seo_snapshot: v.optional(v.any()),
    title_snapshot: v.optional(v.string()),
    slug_snapshot: v.optional(v.string()),
    status_at_revision: v.optional(v.union(v.literal("draft"), v.literal("review"), v.literal("approved"), v.literal("scheduled"), v.literal("published"), v.literal("archived"))),
    reason: v.optional(v.string()),
    is_published_revision: v.optional(v.boolean()),
    created_at: v.string(),
  }),
  relations: v.object({
    entry: v.id("cms_content_entry"),
    author: v.optional(v.id("cms_actor")),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_entry", ["relations.entry"])
  .index("by_author", ["relations.author"])
;
// cms_site — CMS Site
const cmsSiteTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    key: v.string(),
    name: v.string(),
    description: v.optional(v.string()),
    default_locale: v.string(),
    supported_locales: v.optional(v.array(v.any())),
    primary_domain: v.string(),
    additional_domains: v.optional(v.array(v.any())),
    is_default: v.optional(v.boolean()),
    status: v.union(v.literal("active"), v.literal("suspended"), v.literal("archived")),
    settings: v.optional(v.any()),
  }),
  relations: v.object({
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
;
// cms_taxonomy — CMS Taxonomy
const cmsTaxonomyTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    allow_multiple: v.boolean(),
    description: v.optional(v.string()),
    hierarchical: v.boolean(),
    key: v.string(),
    name: v.string(),
  }),
  relations: v.object({
    site: v.optional(v.id("cms_site")),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_site", ["relations.site"])
;
// cms_taxonomy_term — CMS Taxonomy Term
const cmsTaxonomyTermTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    description: v.optional(v.string()),
    key: v.string(),
    metadata: v.optional(v.any()),
    name: v.string(),
    order: v.number(),
    slug: v.string(),
  }),
  relations: v.object({
    parent: v.optional(v.id("cms_taxonomy_term")),
    taxonomy: v.id("cms_taxonomy"),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_parent", ["relations.parent"])
  .index("by_taxonomy", ["relations.taxonomy"])
;
// cms_workflow_log — CMS Workflow Log
const cmsWorkflowLogTable = defineTable({
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: v.object({
    from_status: v.union(v.literal("draft"), v.literal("review"), v.literal("approved"), v.literal("scheduled"), v.literal("published"), v.literal("archived")),
    to_status: v.union(v.literal("draft"), v.literal("review"), v.literal("approved"), v.literal("scheduled"), v.literal("published"), v.literal("archived")),
    event: v.union(v.literal("submit_for_review"), v.literal("approve"), v.literal("reject"), v.literal("schedule"), v.literal("cancel_schedule"), v.literal("publish"), v.literal("unpublish"), v.literal("archive"), v.literal("restore")),
    reason: v.optional(v.string()),
    occurred_at: v.string(),
  }),
  relations: v.object({
    actor: v.optional(v.id("cms_actor")),
    entry: v.id("cms_content_entry"),
  }),
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
})
  .index("by_identifier", ["identifier"])
  .index("by_actor", ["relations.actor"])
  .index("by_entry", ["relations.entry"])
;

const idempotencyTable = defineTable({
  key: v.string(),
  recordId: v.string(),
  createdAt: v.number(),
})
  .index("by_key", ["key"])
;

export default defineSchema({
  cms_actor: cmsActorTable,
  cms_asset: cmsAssetTable,
  cms_asset_variant: cmsAssetVariantTable,
  cms_content_entry: cmsContentEntryTable,
  cms_content_reference: cmsContentReferenceTable,
  cms_content_type: cmsContentTypeTable,
  cms_entry_taxonomy: cmsEntryTaxonomyTable,
  cms_field_definition: cmsFieldDefinitionTable,
  cms_navigation: cmsNavigationTable,
  cms_navigation_item: cmsNavigationItemTable,
  cms_publication: cmsPublicationTable,
  cms_redirect: cmsRedirectTable,
  cms_revision: cmsRevisionTable,
  cms_site: cmsSiteTable,
  cms_taxonomy: cmsTaxonomyTable,
  cms_taxonomy_term: cmsTaxonomyTermTable,
  cms_workflow_log: cmsWorkflowLogTable,
  cms_idempotency_keys: idempotencyTable,
});

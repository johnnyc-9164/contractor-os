// GENERATED from Port blueprint cms_content_entry — do not hand-edit.
// Regenerate with the port-to-convex-component skill.
import { mutation, query } from "../_generated/server";
import { paginationOptsValidator } from "convex/server";
import { paginateComponentQuery } from "../pagination";
import { v, Infer } from "convex/values";
import { cmsContentEntryPropertiesValidator, cmsContentEntryRelationsValidator } from "../validators";
import { cmsContentEntryDocValidator, cmsContentEntryPageValidator } from "../docValidators";

const TABLE = "cms_content_entry" as const;

export const create = mutation({
  args: {
    identifier: v.string(),
    title: v.optional(v.string()),
    properties: cmsContentEntryPropertiesValidator,
    relations: v.optional(cmsContentEntryRelationsValidator),
    idempotencyKey: v.optional(v.string()),
  },
  // Idempotency path returns the stored string copy of the record id, so the exact
  // validator for the union Id | string return is v.string() (opaque id string at the boundary).
  returns: v.string(),
  handler: async (ctx, args) => {
    if (args.idempotencyKey) {
      const prior = await ctx.db
        .query("cms_idempotency_keys")
        .withIndex("by_key", (q) => q.eq("key", args.idempotencyKey as string))
        .unique();
      if (prior) return prior.recordId;
    }
    const existing = await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
    if (existing)
      throw new Error(`cms_content_entry with identifier "${args.identifier}" already exists`);
    const rel = (args.relations ?? {}) as Record<string, any>;
    if (rel.author !== undefined && rel.author !== null) {
      const target = await ctx.db.get(rel.author);
      if (!target) throw new Error("relation author target cms_actor not found");
    }
    if (rel.site !== undefined && rel.site !== null) {
      const target = await ctx.db.get(rel.site);
      if (!target) throw new Error("relation site target cms_site not found");
    }
    if (rel.content_type !== undefined && rel.content_type !== null) {
      const target = await ctx.db.get(rel.content_type);
      if (!target) throw new Error("relation content_type target cms_content_type not found");
    }
    if (rel.last_editor !== undefined && rel.last_editor !== null) {
      const target = await ctx.db.get(rel.last_editor);
      if (!target) throw new Error("relation last_editor target cms_actor not found");
    }
    const id = await ctx.db.insert(TABLE, {
      identifier: args.identifier,
      title: args.title,
      properties: args.properties,
      relations: rel as Infer<typeof cmsContentEntryRelationsValidator>,
      revision: 1,
      sourceBlueprint: TABLE,
    });
    if (args.idempotencyKey) {
      await ctx.db.insert("cms_idempotency_keys", {
        key: args.idempotencyKey,
        recordId: id as unknown as string,
        createdAt: Date.now(),
      });
    }
    return id;
  },
});

export const get = query({
  args: { identifier: v.string() },
  returns: v.union(cmsContentEntryDocValidator, v.null()),
  handler: async (ctx, args) => {
    return await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
  },
});

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    author: v.optional(v.id("cms_actor")),
    site: v.optional(v.id("cms_site")),
    content_type: v.optional(v.id("cms_content_type")),
    last_editor: v.optional(v.id("cms_actor")),
  },
  returns: cmsContentEntryPageValidator,
  handler: async (ctx, args) => {
    // Only the first supplied relation filter applies (single-index queries);
    // further filtering happens client-side from the returned page.
    // NOTE: `.paginate()` is not available inside a Convex component, so
    // pagination is done by hand via paginateComponentQuery (../pagination.ts).
    // Args and return shape ({ page, isDone, continueCursor }) match
    // paginate(), so paginationOptsValidator / usePaginatedQuery keep working.
    const relArgs: Record<string, unknown> = {};
    if ((args as any).author !== undefined) relArgs["author"] = (args as any).author;
    if ((args as any).site !== undefined) relArgs["site"] = (args as any).site;
    if ((args as any).content_type !== undefined) relArgs["content_type"] = (args as any).content_type;
    if ((args as any).last_editor !== undefined) relArgs["last_editor"] = (args as any).last_editor;

    const first = Object.keys(relArgs)[0];
    if (first) {
      const q = ctx.db.query(TABLE).withIndex(("by_" + first) as never, (qq: any) =>
        (qq as any).eq(("relations." + first) as never, relArgs[first] as never),
      );
      return await paginateComponentQuery<Infer<typeof cmsContentEntryDocValidator>>({
        baseQuery: q,
        paginationOpts: args.paginationOpts,
        indexMode: true,
      });
    }
    return await paginateComponentQuery<Infer<typeof cmsContentEntryDocValidator>>({
      baseQuery: ctx.db.query(TABLE),
      paginationOpts: args.paginationOpts,
    });
  },
});

export const update = mutation({
  args: {
    identifier: v.string(),
    expectedRevision: v.number(),
    title: v.optional(v.string()),
    properties: v.optional(cmsContentEntryPropertiesValidator),
    relations: v.optional(cmsContentEntryRelationsValidator),
  },
  returns: v.number(),
  handler: async (ctx, args) => {
    const row = await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
    if (!row) throw new Error(`cms_content_entry not found: ${args.identifier}`);
    if (row.revision !== args.expectedRevision)
      throw new Error(
        `revision conflict on ${args.identifier}: expected ${args.expectedRevision}, found ${row.revision}`,
      );
    const patch: Record<string, unknown> = { revision: row.revision + 1 };
    if (args.title !== undefined) patch.title = args.title;
    if (args.properties !== undefined) patch.properties = args.properties;
    if (args.relations !== undefined) {
      const rel = args.relations as Record<string, any>;
    if (rel.author !== undefined && rel.author !== null) {
      const target = await ctx.db.get(rel.author);
      if (!target) throw new Error("relation author target cms_actor not found");
    }
    if (rel.site !== undefined && rel.site !== null) {
      const target = await ctx.db.get(rel.site);
      if (!target) throw new Error("relation site target cms_site not found");
    }
    if (rel.content_type !== undefined && rel.content_type !== null) {
      const target = await ctx.db.get(rel.content_type);
      if (!target) throw new Error("relation content_type target cms_content_type not found");
    }
    if (rel.last_editor !== undefined && rel.last_editor !== null) {
      const target = await ctx.db.get(rel.last_editor);
      if (!target) throw new Error("relation last_editor target cms_actor not found");
    }
      patch.relations = rel;
    }
    await ctx.db.patch(row._id, patch as never);
    return row.revision + 1;
  },
});

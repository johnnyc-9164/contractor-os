// GENERATED from Port blueprint cms_actor — do not hand-edit.
// Regenerate with the port-to-convex-component skill.
import { mutation, query } from "../_generated/server";
import { paginationOptsValidator } from "convex/server";
import { paginateComponentQuery } from "../pagination";
import { v, Infer } from "convex/values";
import { cmsActorPropertiesValidator, cmsActorRelationsValidator } from "../validators";
import { cmsActorDocValidator, cmsActorPageValidator } from "../docValidators";

const TABLE = "cms_actor" as const;

export const create = mutation({
  args: {
    identifier: v.string(),
    title: v.optional(v.string()),
    properties: cmsActorPropertiesValidator,
    relations: v.optional(cmsActorRelationsValidator),
    idempotencyKey: v.optional(v.string()),
  },
  // Idempotency path returns the stored string copy of the record id, so the exact
  // validator for the union Id | string return is v.string() (opaque id string at the boundary).
  returns: v.string(),
  handler: async (ctx, args) => {
    if (args.idempotencyKey) {
      const prior = await ctx.db
        .query("cms_idempotency_keys")
        .withIndex("by_key", (q) => q.eq("key", args.idempotencyKey as string))
        .unique();
      if (prior) return prior.recordId;
    }
    const existing = await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
    if (existing)
      throw new Error(`cms_actor with identifier "${args.identifier}" already exists`);
    const rel = (args.relations ?? {}) as Record<string, any>;
    // no relations on this blueprint
    const id = await ctx.db.insert(TABLE, {
      identifier: args.identifier,
      title: args.title,
      properties: args.properties,
      relations: rel as Infer<typeof cmsActorRelationsValidator>,
      revision: 1,
      sourceBlueprint: TABLE,
    });
    if (args.idempotencyKey) {
      await ctx.db.insert("cms_idempotency_keys", {
        key: args.idempotencyKey,
        recordId: id as unknown as string,
        createdAt: Date.now(),
      });
    }
    return id;
  },
});

export const get = query({
  args: { identifier: v.string() },
  returns: v.union(cmsActorDocValidator, v.null()),
  handler: async (ctx, args) => {
    return await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
  },
});

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
  },
  returns: cmsActorPageValidator,
  handler: async (ctx, args) => {
    // Only the first supplied relation filter applies (single-index queries);
    // further filtering happens client-side from the returned page.
    // NOTE: `.paginate()` is not available inside a Convex component, so
    // pagination is done by hand via paginateComponentQuery (../pagination.ts).
    // Args and return shape ({ page, isDone, continueCursor }) match
    // paginate(), so paginationOptsValidator / usePaginatedQuery keep working.
    const relArgs: Record<string, unknown> = {};

    const first = Object.keys(relArgs)[0];
    if (first) {
      const q = ctx.db.query(TABLE).withIndex(("by_" + first) as never, (qq: any) =>
        (qq as any).eq(("relations." + first) as never, relArgs[first] as never),
      );
      return await paginateComponentQuery<Infer<typeof cmsActorDocValidator>>({
        baseQuery: q,
        paginationOpts: args.paginationOpts,
        indexMode: true,
      });
    }
    return await paginateComponentQuery<Infer<typeof cmsActorDocValidator>>({
      baseQuery: ctx.db.query(TABLE),
      paginationOpts: args.paginationOpts,
    });
  },
});

export const update = mutation({
  args: {
    identifier: v.string(),
    expectedRevision: v.number(),
    title: v.optional(v.string()),
    properties: v.optional(cmsActorPropertiesValidator),
    relations: v.optional(cmsActorRelationsValidator),
  },
  returns: v.number(),
  handler: async (ctx, args) => {
    const row = await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
    if (!row) throw new Error(`cms_actor not found: ${args.identifier}`);
    if (row.revision !== args.expectedRevision)
      throw new Error(
        `revision conflict on ${args.identifier}: expected ${args.expectedRevision}, found ${row.revision}`,
      );
    const patch: Record<string, unknown> = { revision: row.revision + 1 };
    if (args.title !== undefined) patch.title = args.title;
    if (args.properties !== undefined) patch.properties = args.properties;
    if (args.relations !== undefined) {
      const rel = args.relations as Record<string, any>;
    // no relations on this blueprint
      patch.relations = rel;
    }
    await ctx.db.patch(row._id, patch as never);
    return row.revision + 1;
  },
});

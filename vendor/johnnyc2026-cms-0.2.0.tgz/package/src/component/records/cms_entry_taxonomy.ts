// GENERATED from Port blueprint cms_entry_taxonomy — do not hand-edit.
// Regenerate with the port-to-convex-component skill.
import { mutation, query } from "../_generated/server";
import { paginationOptsValidator } from "convex/server";
import { paginateComponentQuery } from "../pagination";
import { v, Infer } from "convex/values";
import { cmsEntryTaxonomyPropertiesValidator, cmsEntryTaxonomyRelationsValidator } from "../validators";
import { cmsEntryTaxonomyDocValidator, cmsEntryTaxonomyPageValidator } from "../docValidators";

const TABLE = "cms_entry_taxonomy" as const;

export const create = mutation({
  args: {
    identifier: v.string(),
    title: v.optional(v.string()),
    properties: cmsEntryTaxonomyPropertiesValidator,
    relations: v.optional(cmsEntryTaxonomyRelationsValidator),
    idempotencyKey: v.optional(v.string()),
  },
  // Idempotency path returns the stored string copy of the record id, so the exact
  // validator for the union Id | string return is v.string() (opaque id string at the boundary).
  returns: v.string(),
  handler: async (ctx, args) => {
    if (args.idempotencyKey) {
      const prior = await ctx.db
        .query("cms_idempotency_keys")
        .withIndex("by_key", (q) => q.eq("key", args.idempotencyKey as string))
        .unique();
      if (prior) return prior.recordId;
    }
    const existing = await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
    if (existing)
      throw new Error(`cms_entry_taxonomy with identifier "${args.identifier}" already exists`);
    const rel = (args.relations ?? {}) as Record<string, any>;
    if (rel.entry !== undefined && rel.entry !== null) {
      const target = await ctx.db.get(rel.entry);
      if (!target) throw new Error("relation entry target cms_content_entry not found");
    }
    if (rel.term !== undefined && rel.term !== null) {
      const target = await ctx.db.get(rel.term);
      if (!target) throw new Error("relation term target cms_taxonomy_term not found");
    }
    if (rel.assigned_by !== undefined && rel.assigned_by !== null) {
      const target = await ctx.db.get(rel.assigned_by);
      if (!target) throw new Error("relation assigned_by target cms_actor not found");
    }
    const id = await ctx.db.insert(TABLE, {
      identifier: args.identifier,
      title: args.title,
      properties: args.properties,
      relations: rel as Infer<typeof cmsEntryTaxonomyRelationsValidator>,
      revision: 1,
      sourceBlueprint: TABLE,
    });
    if (args.idempotencyKey) {
      await ctx.db.insert("cms_idempotency_keys", {
        key: args.idempotencyKey,
        recordId: id as unknown as string,
        createdAt: Date.now(),
      });
    }
    return id;
  },
});

export const get = query({
  args: { identifier: v.string() },
  returns: v.union(cmsEntryTaxonomyDocValidator, v.null()),
  handler: async (ctx, args) => {
    return await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
  },
});

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    entry: v.optional(v.id("cms_content_entry")),
    term: v.optional(v.id("cms_taxonomy_term")),
    assigned_by: v.optional(v.id("cms_actor")),
  },
  returns: cmsEntryTaxonomyPageValidator,
  handler: async (ctx, args) => {
    // Only the first supplied relation filter applies (single-index queries);
    // further filtering happens client-side from the returned page.
    // NOTE: `.paginate()` is not available inside a Convex component, so
    // pagination is done by hand via paginateComponentQuery (../pagination.ts).
    // Args and return shape ({ page, isDone, continueCursor }) match
    // paginate(), so paginationOptsValidator / usePaginatedQuery keep working.
    const relArgs: Record<string, unknown> = {};
    if ((args as any).entry !== undefined) relArgs["entry"] = (args as any).entry;
    if ((args as any).term !== undefined) relArgs["term"] = (args as any).term;
    if ((args as any).assigned_by !== undefined) relArgs["assigned_by"] = (args as any).assigned_by;

    const first = Object.keys(relArgs)[0];
    if (first) {
      const q = ctx.db.query(TABLE).withIndex(("by_" + first) as never, (qq: any) =>
        (qq as any).eq(("relations." + first) as never, relArgs[first] as never),
      );
      return await paginateComponentQuery<Infer<typeof cmsEntryTaxonomyDocValidator>>({
        baseQuery: q,
        paginationOpts: args.paginationOpts,
        indexMode: true,
      });
    }
    return await paginateComponentQuery<Infer<typeof cmsEntryTaxonomyDocValidator>>({
      baseQuery: ctx.db.query(TABLE),
      paginationOpts: args.paginationOpts,
    });
  },
});

export const update = mutation({
  args: {
    identifier: v.string(),
    expectedRevision: v.number(),
    title: v.optional(v.string()),
    properties: v.optional(cmsEntryTaxonomyPropertiesValidator),
    relations: v.optional(cmsEntryTaxonomyRelationsValidator),
  },
  returns: v.number(),
  handler: async (ctx, args) => {
    const row = await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
    if (!row) throw new Error(`cms_entry_taxonomy not found: ${args.identifier}`);
    if (row.revision !== args.expectedRevision)
      throw new Error(
        `revision conflict on ${args.identifier}: expected ${args.expectedRevision}, found ${row.revision}`,
      );
    const patch: Record<string, unknown> = { revision: row.revision + 1 };
    if (args.title !== undefined) patch.title = args.title;
    if (args.properties !== undefined) patch.properties = args.properties;
    if (args.relations !== undefined) {
      const rel = args.relations as Record<string, any>;
    if (rel.entry !== undefined && rel.entry !== null) {
      const target = await ctx.db.get(rel.entry);
      if (!target) throw new Error("relation entry target cms_content_entry not found");
    }
    if (rel.term !== undefined && rel.term !== null) {
      const target = await ctx.db.get(rel.term);
      if (!target) throw new Error("relation term target cms_taxonomy_term not found");
    }
    if (rel.assigned_by !== undefined && rel.assigned_by !== null) {
      const target = await ctx.db.get(rel.assigned_by);
      if (!target) throw new Error("relation assigned_by target cms_actor not found");
    }
      patch.relations = rel;
    }
    await ctx.db.patch(row._id, patch as never);
    return row.revision + 1;
  },
});

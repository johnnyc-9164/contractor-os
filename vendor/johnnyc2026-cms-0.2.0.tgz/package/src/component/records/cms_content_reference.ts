// GENERATED from Port blueprint cms_content_reference — do not hand-edit.
// Regenerate with the port-to-convex-component skill.
import { mutation, query } from "../_generated/server";
import { paginationOptsValidator } from "convex/server";
import { paginateComponentQuery } from "../pagination";
import { v, Infer } from "convex/values";
import { cmsContentReferencePropertiesValidator, cmsContentReferenceRelationsValidator } from "../validators";
import { cmsContentReferenceDocValidator, cmsContentReferencePageValidator } from "../docValidators";

const TABLE = "cms_content_reference" as const;

export const create = mutation({
  args: {
    identifier: v.string(),
    title: v.optional(v.string()),
    properties: cmsContentReferencePropertiesValidator,
    relations: v.optional(cmsContentReferenceRelationsValidator),
    idempotencyKey: v.optional(v.string()),
  },
  // Idempotency path returns the stored string copy of the record id, so the exact
  // validator for the union Id | string return is v.string() (opaque id string at the boundary).
  returns: v.string(),
  handler: async (ctx, args) => {
    if (args.idempotencyKey) {
      const prior = await ctx.db
        .query("cms_idempotency_keys")
        .withIndex("by_key", (q) => q.eq("key", args.idempotencyKey as string))
        .unique();
      if (prior) return prior.recordId;
    }
    const existing = await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
    if (existing)
      throw new Error(`cms_content_reference with identifier "${args.identifier}" already exists`);
    const rel = (args.relations ?? {}) as Record<string, any>;
    if (rel.source_entry !== undefined && rel.source_entry !== null) {
      const target = await ctx.db.get(rel.source_entry);
      if (!target) throw new Error("relation source_entry target cms_content_entry not found");
    }
    if (rel.target_asset !== undefined && rel.target_asset !== null) {
      const target = await ctx.db.get(rel.target_asset);
      if (!target) throw new Error("relation target_asset target cms_asset not found");
    }
    if (rel.target_entry !== undefined && rel.target_entry !== null) {
      const target = await ctx.db.get(rel.target_entry);
      if (!target) throw new Error("relation target_entry target cms_content_entry not found");
    }
    const id = await ctx.db.insert(TABLE, {
      identifier: args.identifier,
      title: args.title,
      properties: args.properties,
      relations: rel as Infer<typeof cmsContentReferenceRelationsValidator>,
      revision: 1,
      sourceBlueprint: TABLE,
    });
    if (args.idempotencyKey) {
      await ctx.db.insert("cms_idempotency_keys", {
        key: args.idempotencyKey,
        recordId: id as unknown as string,
        createdAt: Date.now(),
      });
    }
    return id;
  },
});

export const get = query({
  args: { identifier: v.string() },
  returns: v.union(cmsContentReferenceDocValidator, v.null()),
  handler: async (ctx, args) => {
    return await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
  },
});

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    source_entry: v.optional(v.id("cms_content_entry")),
    target_asset: v.optional(v.id("cms_asset")),
    target_entry: v.optional(v.id("cms_content_entry")),
  },
  returns: cmsContentReferencePageValidator,
  handler: async (ctx, args) => {
    // Only the first supplied relation filter applies (single-index queries);
    // further filtering happens client-side from the returned page.
    // NOTE: `.paginate()` is not available inside a Convex component, so
    // pagination is done by hand via paginateComponentQuery (../pagination.ts).
    // Args and return shape ({ page, isDone, continueCursor }) match
    // paginate(), so paginationOptsValidator / usePaginatedQuery keep working.
    const relArgs: Record<string, unknown> = {};
    if ((args as any).source_entry !== undefined) relArgs["source_entry"] = (args as any).source_entry;
    if ((args as any).target_asset !== undefined) relArgs["target_asset"] = (args as any).target_asset;
    if ((args as any).target_entry !== undefined) relArgs["target_entry"] = (args as any).target_entry;

    const first = Object.keys(relArgs)[0];
    if (first) {
      const q = ctx.db.query(TABLE).withIndex(("by_" + first) as never, (qq: any) =>
        (qq as any).eq(("relations." + first) as never, relArgs[first] as never),
      );
      return await paginateComponentQuery<Infer<typeof cmsContentReferenceDocValidator>>({
        baseQuery: q,
        paginationOpts: args.paginationOpts,
        indexMode: true,
      });
    }
    return await paginateComponentQuery<Infer<typeof cmsContentReferenceDocValidator>>({
      baseQuery: ctx.db.query(TABLE),
      paginationOpts: args.paginationOpts,
    });
  },
});

export const update = mutation({
  args: {
    identifier: v.string(),
    expectedRevision: v.number(),
    title: v.optional(v.string()),
    properties: v.optional(cmsContentReferencePropertiesValidator),
    relations: v.optional(cmsContentReferenceRelationsValidator),
  },
  returns: v.number(),
  handler: async (ctx, args) => {
    const row = await ctx.db
      .query(TABLE)
      .withIndex("by_identifier", (q) => q.eq("identifier", args.identifier))
      .unique();
    if (!row) throw new Error(`cms_content_reference not found: ${args.identifier}`);
    if (row.revision !== args.expectedRevision)
      throw new Error(
        `revision conflict on ${args.identifier}: expected ${args.expectedRevision}, found ${row.revision}`,
      );
    const patch: Record<string, unknown> = { revision: row.revision + 1 };
    if (args.title !== undefined) patch.title = args.title;
    if (args.properties !== undefined) patch.properties = args.properties;
    if (args.relations !== undefined) {
      const rel = args.relations as Record<string, any>;
    if (rel.source_entry !== undefined && rel.source_entry !== null) {
      const target = await ctx.db.get(rel.source_entry);
      if (!target) throw new Error("relation source_entry target cms_content_entry not found");
    }
    if (rel.target_asset !== undefined && rel.target_asset !== null) {
      const target = await ctx.db.get(rel.target_asset);
      if (!target) throw new Error("relation target_asset target cms_asset not found");
    }
    if (rel.target_entry !== undefined && rel.target_entry !== null) {
      const target = await ctx.db.get(rel.target_entry);
      if (!target) throw new Error("relation target_entry target cms_content_entry not found");
    }
      patch.relations = rel;
    }
    await ctx.db.patch(row._id, patch as never);
    return row.revision + 1;
  },
});

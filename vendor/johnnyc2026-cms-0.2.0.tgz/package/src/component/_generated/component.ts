/* eslint-disable */
/**
 * Generated `ComponentApi` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type { FunctionReference } from "convex/server";

/**
 * A utility for referencing a Convex component's exposed API.
 *
 * Useful when expecting a parameter like `components.myComponent`.
 * Usage:
 * ```ts
 * async function myFunction(ctx: QueryCtx, component: ComponentApi) {
 *   return ctx.runQuery(component.someFile.someQuery, { ...args });
 * }
 * ```
 */
export type ComponentApi<Name extends string | undefined = string | undefined> =
  {
    records: {
      cms_actor: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              display_name: string;
              email: string;
              external_auth_id: string;
              external_auth_provider:
                "betterauth" | "clerk" | "workos" | "custom";
              role:
                "viewer" | "author" | "editor" | "publisher" | "administrator";
              site_scope?: Array<any>;
            };
            relations?: {};
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              display_name: string;
              email: string;
              external_auth_id: string;
              external_auth_provider:
                "betterauth" | "clerk" | "workos" | "custom";
              role:
                "viewer" | "author" | "editor" | "publisher" | "administrator";
              site_scope?: Array<any>;
            };
            relations: {};
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                display_name: string;
                email: string;
                external_auth_id: string;
                external_auth_provider:
                  "betterauth" | "clerk" | "workos" | "custom";
                role:
                  | "viewer"
                  | "author"
                  | "editor"
                  | "publisher"
                  | "administrator";
                site_scope?: Array<any>;
              };
              relations: {};
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              display_name: string;
              email: string;
              external_auth_id: string;
              external_auth_provider:
                "betterauth" | "clerk" | "workos" | "custom";
              role:
                "viewer" | "author" | "editor" | "publisher" | "administrator";
              site_scope?: Array<any>;
            };
            relations?: {};
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_asset: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              alt_text?: string;
              asset_type: "image" | "video" | "audio" | "document" | "file";
              caption?: string;
              checksum: string;
              deleted_at?: string;
              duration_seconds?: number;
              filename: string;
              height_px?: number;
              metadata?: any;
              mime_type: string;
              size_bytes: number;
              storage_key: string;
              width_px?: number;
            };
            relations?: { site?: string; uploaded_by?: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              alt_text?: string;
              asset_type: "image" | "video" | "audio" | "document" | "file";
              caption?: string;
              checksum: string;
              deleted_at?: string;
              duration_seconds?: number;
              filename: string;
              height_px?: number;
              metadata?: any;
              mime_type: string;
              size_bytes: number;
              storage_key: string;
              width_px?: number;
            };
            relations: { site?: string; uploaded_by?: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            site?: string;
            uploaded_by?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                alt_text?: string;
                asset_type: "image" | "video" | "audio" | "document" | "file";
                caption?: string;
                checksum: string;
                deleted_at?: string;
                duration_seconds?: number;
                filename: string;
                height_px?: number;
                metadata?: any;
                mime_type: string;
                size_bytes: number;
                storage_key: string;
                width_px?: number;
              };
              relations: { site?: string; uploaded_by?: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              alt_text?: string;
              asset_type: "image" | "video" | "audio" | "document" | "file";
              caption?: string;
              checksum: string;
              deleted_at?: string;
              duration_seconds?: number;
              filename: string;
              height_px?: number;
              metadata?: any;
              mime_type: string;
              size_bytes: number;
              storage_key: string;
              width_px?: number;
            };
            relations?: { site?: string; uploaded_by?: string };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_asset_variant: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              height_px?: number;
              key: string;
              mime_type: string;
              size_bytes: number;
              storage_key: string;
              transform_config: any;
              width_px?: number;
            };
            relations?: { asset: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              height_px?: number;
              key: string;
              mime_type: string;
              size_bytes: number;
              storage_key: string;
              transform_config: any;
              width_px?: number;
            };
            relations: { asset: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            asset?: string;
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                height_px?: number;
                key: string;
                mime_type: string;
                size_bytes: number;
                storage_key: string;
                transform_config: any;
                width_px?: number;
              };
              relations: { asset: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              height_px?: number;
              key: string;
              mime_type: string;
              size_bytes: number;
              storage_key: string;
              transform_config: any;
              width_px?: number;
            };
            relations?: { asset: string };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_content_entry: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              archived_at?: string;
              content_type_key: string;
              data?: any;
              deleted_at?: string;
              locale: string;
              published_at?: string;
              scheduled_publish_at?: string;
              scheduled_unpublish_at?: string;
              seo_canonical_url?: string;
              seo_meta_description?: string;
              seo_robots?:
                | "index_follow"
                | "index_nofollow"
                | "noindex_follow"
                | "noindex_nofollow";
              seo_sitemap_changefreq?:
                | "always"
                | "hourly"
                | "daily"
                | "weekly"
                | "monthly"
                | "yearly"
                | "never";
              seo_sitemap_include?: boolean;
              seo_sitemap_priority?: number;
              seo_social_description?: string;
              seo_social_title?: string;
              seo_structured_data?: any;
              seo_title?: string;
              slug: string;
              status:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
              title: string;
              translation_group_id?: string;
            };
            relations?: {
              author?: string;
              content_type: string;
              last_editor?: string;
              site: string;
            };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              archived_at?: string;
              content_type_key: string;
              data?: any;
              deleted_at?: string;
              locale: string;
              published_at?: string;
              scheduled_publish_at?: string;
              scheduled_unpublish_at?: string;
              seo_canonical_url?: string;
              seo_meta_description?: string;
              seo_robots?:
                | "index_follow"
                | "index_nofollow"
                | "noindex_follow"
                | "noindex_nofollow";
              seo_sitemap_changefreq?:
                | "always"
                | "hourly"
                | "daily"
                | "weekly"
                | "monthly"
                | "yearly"
                | "never";
              seo_sitemap_include?: boolean;
              seo_sitemap_priority?: number;
              seo_social_description?: string;
              seo_social_title?: string;
              seo_structured_data?: any;
              seo_title?: string;
              slug: string;
              status:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
              title: string;
              translation_group_id?: string;
            };
            relations: {
              author?: string;
              content_type: string;
              last_editor?: string;
              site: string;
            };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            author?: string;
            content_type?: string;
            last_editor?: string;
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            site?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                archived_at?: string;
                content_type_key: string;
                data?: any;
                deleted_at?: string;
                locale: string;
                published_at?: string;
                scheduled_publish_at?: string;
                scheduled_unpublish_at?: string;
                seo_canonical_url?: string;
                seo_meta_description?: string;
                seo_robots?:
                  | "index_follow"
                  | "index_nofollow"
                  | "noindex_follow"
                  | "noindex_nofollow";
                seo_sitemap_changefreq?:
                  | "always"
                  | "hourly"
                  | "daily"
                  | "weekly"
                  | "monthly"
                  | "yearly"
                  | "never";
                seo_sitemap_include?: boolean;
                seo_sitemap_priority?: number;
                seo_social_description?: string;
                seo_social_title?: string;
                seo_structured_data?: any;
                seo_title?: string;
                slug: string;
                status:
                  | "draft"
                  | "review"
                  | "approved"
                  | "scheduled"
                  | "published"
                  | "archived";
                title: string;
                translation_group_id?: string;
              };
              relations: {
                author?: string;
                content_type: string;
                last_editor?: string;
                site: string;
              };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              archived_at?: string;
              content_type_key: string;
              data?: any;
              deleted_at?: string;
              locale: string;
              published_at?: string;
              scheduled_publish_at?: string;
              scheduled_unpublish_at?: string;
              seo_canonical_url?: string;
              seo_meta_description?: string;
              seo_robots?:
                | "index_follow"
                | "index_nofollow"
                | "noindex_follow"
                | "noindex_nofollow";
              seo_sitemap_changefreq?:
                | "always"
                | "hourly"
                | "daily"
                | "weekly"
                | "monthly"
                | "yearly"
                | "never";
              seo_sitemap_include?: boolean;
              seo_sitemap_priority?: number;
              seo_social_description?: string;
              seo_social_title?: string;
              seo_structured_data?: any;
              seo_title?: string;
              slug: string;
              status:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
              title: string;
              translation_group_id?: string;
            };
            relations?: {
              author?: string;
              content_type: string;
              last_editor?: string;
              site: string;
            };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_content_reference: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              context?: string;
              created_at: string;
              display_order?: number;
              external_component?: string;
              external_entity_id?: string;
              external_entity_type?: string;
              source_field?: string;
              target_type: "entry" | "asset" | "external";
            };
            relations?: {
              source_entry: string;
              target_asset?: string;
              target_entry?: string;
            };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              context?: string;
              created_at: string;
              display_order?: number;
              external_component?: string;
              external_entity_id?: string;
              external_entity_type?: string;
              source_field?: string;
              target_type: "entry" | "asset" | "external";
            };
            relations: {
              source_entry: string;
              target_asset?: string;
              target_entry?: string;
            };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            source_entry?: string;
            target_asset?: string;
            target_entry?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                context?: string;
                created_at: string;
                display_order?: number;
                external_component?: string;
                external_entity_id?: string;
                external_entity_type?: string;
                source_field?: string;
                target_type: "entry" | "asset" | "external";
              };
              relations: {
                source_entry: string;
                target_asset?: string;
                target_entry?: string;
              };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              context?: string;
              created_at: string;
              display_order?: number;
              external_component?: string;
              external_entity_id?: string;
              external_entity_type?: string;
              source_field?: string;
              target_type: "entry" | "asset" | "external";
            };
            relations?: {
              source_entry: string;
              target_asset?: string;
              target_entry?: string;
            };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_content_type: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              description?: string;
              enabled: boolean;
              icon_name?: string;
              key: string;
              name: string;
              revision_limit?: number;
              seo_enabled?: boolean;
              singleton: boolean;
            };
            relations?: { site?: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              description?: string;
              enabled: boolean;
              icon_name?: string;
              key: string;
              name: string;
              revision_limit?: number;
              seo_enabled?: boolean;
              singleton: boolean;
            };
            relations: { site?: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            site?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                description?: string;
                enabled: boolean;
                icon_name?: string;
                key: string;
                name: string;
                revision_limit?: number;
                seo_enabled?: boolean;
                singleton: boolean;
              };
              relations: { site?: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              description?: string;
              enabled: boolean;
              icon_name?: string;
              key: string;
              name: string;
              revision_limit?: number;
              seo_enabled?: boolean;
              singleton: boolean;
            };
            relations?: { site?: string };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_entry_taxonomy: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: { assigned_at: string };
            relations?: { assigned_by?: string; entry: string; term: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: { assigned_at: string };
            relations: { assigned_by?: string; entry: string; term: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            assigned_by?: string;
            entry?: string;
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            term?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: { assigned_at: string };
              relations: { assigned_by?: string; entry: string; term: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: { assigned_at: string };
            relations?: { assigned_by?: string; entry: string; term: string };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_field_definition: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              allowed_values?: Array<any>;
              default_value?: string;
              description?: string;
              field_type:
                | "text"
                | "richText"
                | "number"
                | "boolean"
                | "date"
                | "datetime"
                | "select"
                | "multiSelect"
                | "slug"
                | "url"
                | "email"
                | "json"
                | "asset"
                | "assetList"
                | "reference"
                | "referenceList"
                | "object"
                | "objectList";
              hidden?: boolean;
              key: string;
              label: string;
              localized?: boolean;
              max_length?: number;
              max_value?: number;
              min_length?: number;
              min_value?: number;
              order: number;
              pattern?: string;
              reference_target_types?: Array<any>;
              required: boolean;
              searchable?: boolean;
              unique_field?: boolean;
            };
            relations?: { content_type: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              allowed_values?: Array<any>;
              default_value?: string;
              description?: string;
              field_type:
                | "text"
                | "richText"
                | "number"
                | "boolean"
                | "date"
                | "datetime"
                | "select"
                | "multiSelect"
                | "slug"
                | "url"
                | "email"
                | "json"
                | "asset"
                | "assetList"
                | "reference"
                | "referenceList"
                | "object"
                | "objectList";
              hidden?: boolean;
              key: string;
              label: string;
              localized?: boolean;
              max_length?: number;
              max_value?: number;
              min_length?: number;
              min_value?: number;
              order: number;
              pattern?: string;
              reference_target_types?: Array<any>;
              required: boolean;
              searchable?: boolean;
              unique_field?: boolean;
            };
            relations: { content_type: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            content_type?: string;
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                allowed_values?: Array<any>;
                default_value?: string;
                description?: string;
                field_type:
                  | "text"
                  | "richText"
                  | "number"
                  | "boolean"
                  | "date"
                  | "datetime"
                  | "select"
                  | "multiSelect"
                  | "slug"
                  | "url"
                  | "email"
                  | "json"
                  | "asset"
                  | "assetList"
                  | "reference"
                  | "referenceList"
                  | "object"
                  | "objectList";
                hidden?: boolean;
                key: string;
                label: string;
                localized?: boolean;
                max_length?: number;
                max_value?: number;
                min_length?: number;
                min_value?: number;
                order: number;
                pattern?: string;
                reference_target_types?: Array<any>;
                required: boolean;
                searchable?: boolean;
                unique_field?: boolean;
              };
              relations: { content_type: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              allowed_values?: Array<any>;
              default_value?: string;
              description?: string;
              field_type:
                | "text"
                | "richText"
                | "number"
                | "boolean"
                | "date"
                | "datetime"
                | "select"
                | "multiSelect"
                | "slug"
                | "url"
                | "email"
                | "json"
                | "asset"
                | "assetList"
                | "reference"
                | "referenceList"
                | "object"
                | "objectList";
              hidden?: boolean;
              key: string;
              label: string;
              localized?: boolean;
              max_length?: number;
              max_value?: number;
              min_length?: number;
              min_value?: number;
              order: number;
              pattern?: string;
              reference_target_types?: Array<any>;
              required: boolean;
              searchable?: boolean;
              unique_field?: boolean;
            };
            relations?: { content_type: string };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_navigation: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              description?: string;
              enabled: boolean;
              key: string;
              locale?: string;
              name: string;
            };
            relations?: { site: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              description?: string;
              enabled: boolean;
              key: string;
              locale?: string;
              name: string;
            };
            relations: { site: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            site?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                description?: string;
                enabled: boolean;
                key: string;
                locale?: string;
                name: string;
              };
              relations: { site: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              description?: string;
              enabled: boolean;
              key: string;
              locale?: string;
              name: string;
            };
            relations?: { site: string };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_navigation_item: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              is_broken?: boolean;
              label: string;
              metadata?: any;
              order: number;
              target: "self" | "blank" | "parent" | "top";
              url?: string;
              visibility:
                "always" | "authenticated" | "unauthenticated" | "hidden";
            };
            relations?: {
              entry?: string;
              navigation: string;
              parent_item?: string;
            };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              is_broken?: boolean;
              label: string;
              metadata?: any;
              order: number;
              target: "self" | "blank" | "parent" | "top";
              url?: string;
              visibility:
                "always" | "authenticated" | "unauthenticated" | "hidden";
            };
            relations: {
              entry?: string;
              navigation: string;
              parent_item?: string;
            };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            entry?: string;
            navigation?: string;
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            parent_item?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                is_broken?: boolean;
                label: string;
                metadata?: any;
                order: number;
                target: "self" | "blank" | "parent" | "top";
                url?: string;
                visibility:
                  "always" | "authenticated" | "unauthenticated" | "hidden";
              };
              relations: {
                entry?: string;
                navigation: string;
                parent_item?: string;
              };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              is_broken?: boolean;
              label: string;
              metadata?: any;
              order: number;
              target: "self" | "blank" | "parent" | "top";
              url?: string;
              visibility:
                "always" | "authenticated" | "unauthenticated" | "hidden";
            };
            relations?: {
              entry?: string;
              navigation: string;
              parent_item?: string;
            };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_publication: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              action: "publish" | "unpublish" | "schedule" | "cancel_schedule";
              channel?: string;
              note?: string;
              previous_revision_number?: number;
              published_at: string;
              revision_number?: number;
              scheduled_for?: string;
            };
            relations?: {
              entry: string;
              previous_revision?: string;
              published_by?: string;
              revision: string;
              site: string;
            };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              action: "publish" | "unpublish" | "schedule" | "cancel_schedule";
              channel?: string;
              note?: string;
              previous_revision_number?: number;
              published_at: string;
              revision_number?: number;
              scheduled_for?: string;
            };
            relations: {
              entry: string;
              previous_revision?: string;
              published_by?: string;
              revision: string;
              site: string;
            };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            entry?: string;
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            previous_revision?: string;
            published_by?: string;
            revision?: string;
            site?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                action:
                  "publish" | "unpublish" | "schedule" | "cancel_schedule";
                channel?: string;
                note?: string;
                previous_revision_number?: number;
                published_at: string;
                revision_number?: number;
                scheduled_for?: string;
              };
              relations: {
                entry: string;
                previous_revision?: string;
                published_by?: string;
                revision: string;
                site: string;
              };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              action: "publish" | "unpublish" | "schedule" | "cancel_schedule";
              channel?: string;
              note?: string;
              previous_revision_number?: number;
              published_at: string;
              revision_number?: number;
              scheduled_for?: string;
            };
            relations?: {
              entry: string;
              previous_revision?: string;
              published_by?: string;
              revision: string;
              site: string;
            };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_redirect: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              destination?: string;
              enabled: boolean;
              note?: string;
              source_path: string;
              status_code: "301" | "302" | "307" | "308" | "410";
            };
            relations?: { site: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              destination?: string;
              enabled: boolean;
              note?: string;
              source_path: string;
              status_code: "301" | "302" | "307" | "308" | "410";
            };
            relations: { site: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            site?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                destination?: string;
                enabled: boolean;
                note?: string;
                source_path: string;
                status_code: "301" | "302" | "307" | "308" | "410";
              };
              relations: { site: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              destination?: string;
              enabled: boolean;
              note?: string;
              source_path: string;
              status_code: "301" | "302" | "307" | "308" | "410";
            };
            relations?: { site: string };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_revision: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              created_at: string;
              data_snapshot: any;
              is_published_revision?: boolean;
              reason?: string;
              revision_number: number;
              seo_snapshot?: any;
              slug_snapshot?: string;
              status_at_revision?:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
              title_snapshot?: string;
            };
            relations?: { author?: string; entry: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              created_at: string;
              data_snapshot: any;
              is_published_revision?: boolean;
              reason?: string;
              revision_number: number;
              seo_snapshot?: any;
              slug_snapshot?: string;
              status_at_revision?:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
              title_snapshot?: string;
            };
            relations: { author?: string; entry: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            author?: string;
            entry?: string;
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                created_at: string;
                data_snapshot: any;
                is_published_revision?: boolean;
                reason?: string;
                revision_number: number;
                seo_snapshot?: any;
                slug_snapshot?: string;
                status_at_revision?:
                  | "draft"
                  | "review"
                  | "approved"
                  | "scheduled"
                  | "published"
                  | "archived";
                title_snapshot?: string;
              };
              relations: { author?: string; entry: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              created_at: string;
              data_snapshot: any;
              is_published_revision?: boolean;
              reason?: string;
              revision_number: number;
              seo_snapshot?: any;
              slug_snapshot?: string;
              status_at_revision?:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
              title_snapshot?: string;
            };
            relations?: { author?: string; entry: string };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_site: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              additional_domains?: Array<any>;
              default_locale: string;
              description?: string;
              is_default?: boolean;
              key: string;
              name: string;
              primary_domain: string;
              settings?: any;
              status: "active" | "suspended" | "archived";
              supported_locales?: Array<any>;
            };
            relations?: {};
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              additional_domains?: Array<any>;
              default_locale: string;
              description?: string;
              is_default?: boolean;
              key: string;
              name: string;
              primary_domain: string;
              settings?: any;
              status: "active" | "suspended" | "archived";
              supported_locales?: Array<any>;
            };
            relations: {};
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                additional_domains?: Array<any>;
                default_locale: string;
                description?: string;
                is_default?: boolean;
                key: string;
                name: string;
                primary_domain: string;
                settings?: any;
                status: "active" | "suspended" | "archived";
                supported_locales?: Array<any>;
              };
              relations: {};
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              additional_domains?: Array<any>;
              default_locale: string;
              description?: string;
              is_default?: boolean;
              key: string;
              name: string;
              primary_domain: string;
              settings?: any;
              status: "active" | "suspended" | "archived";
              supported_locales?: Array<any>;
            };
            relations?: {};
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_taxonomy: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              allow_multiple: boolean;
              description?: string;
              hierarchical: boolean;
              key: string;
              name: string;
            };
            relations?: { site?: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              allow_multiple: boolean;
              description?: string;
              hierarchical: boolean;
              key: string;
              name: string;
            };
            relations: { site?: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            site?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                allow_multiple: boolean;
                description?: string;
                hierarchical: boolean;
                key: string;
                name: string;
              };
              relations: { site?: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              allow_multiple: boolean;
              description?: string;
              hierarchical: boolean;
              key: string;
              name: string;
            };
            relations?: { site?: string };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_taxonomy_term: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              description?: string;
              key: string;
              metadata?: any;
              name: string;
              order: number;
              slug: string;
            };
            relations?: { parent?: string; taxonomy: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              description?: string;
              key: string;
              metadata?: any;
              name: string;
              order: number;
              slug: string;
            };
            relations: { parent?: string; taxonomy: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
            parent?: string;
            taxonomy?: string;
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                description?: string;
                key: string;
                metadata?: any;
                name: string;
                order: number;
                slug: string;
              };
              relations: { parent?: string; taxonomy: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              description?: string;
              key: string;
              metadata?: any;
              name: string;
              order: number;
              slug: string;
            };
            relations?: { parent?: string; taxonomy: string };
            title?: string;
          },
          number,
          Name
        >;
      };
      cms_workflow_log: {
        create: FunctionReference<
          "mutation",
          "internal",
          {
            idempotencyKey?: string;
            identifier: string;
            properties: {
              event:
                | "submit_for_review"
                | "approve"
                | "reject"
                | "schedule"
                | "cancel_schedule"
                | "publish"
                | "unpublish"
                | "archive"
                | "restore";
              from_status:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
              occurred_at: string;
              reason?: string;
              to_status:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
            };
            relations?: { actor?: string; entry: string };
            title?: string;
          },
          string,
          Name
        >;
        get: FunctionReference<
          "query",
          "internal",
          { identifier: string },
          {
            _creationTime: number;
            _id: string;
            identifier: string;
            properties: {
              event:
                | "submit_for_review"
                | "approve"
                | "reject"
                | "schedule"
                | "cancel_schedule"
                | "publish"
                | "unpublish"
                | "archive"
                | "restore";
              from_status:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
              occurred_at: string;
              reason?: string;
              to_status:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
            };
            relations: { actor?: string; entry: string };
            revision: number;
            sourceBlueprint: string;
            sourceUpdatedAt?: string;
            title?: string;
          } | null,
          Name
        >;
        list: FunctionReference<
          "query",
          "internal",
          {
            actor?: string;
            entry?: string;
            paginationOpts: {
              cursor: string | null;
              endCursor?: string | null;
              id?: number;
              maximumBytesRead?: number;
              maximumRowsRead?: number;
              numItems: number;
            };
          },
          {
            continueCursor: string | null;
            isDone: boolean;
            page: Array<{
              _creationTime: number;
              _id: string;
              identifier: string;
              properties: {
                event:
                  | "submit_for_review"
                  | "approve"
                  | "reject"
                  | "schedule"
                  | "cancel_schedule"
                  | "publish"
                  | "unpublish"
                  | "archive"
                  | "restore";
                from_status:
                  | "draft"
                  | "review"
                  | "approved"
                  | "scheduled"
                  | "published"
                  | "archived";
                occurred_at: string;
                reason?: string;
                to_status:
                  | "draft"
                  | "review"
                  | "approved"
                  | "scheduled"
                  | "published"
                  | "archived";
              };
              relations: { actor?: string; entry: string };
              revision: number;
              sourceBlueprint: string;
              sourceUpdatedAt?: string;
              title?: string;
            }>;
          },
          Name
        >;
        update: FunctionReference<
          "mutation",
          "internal",
          {
            expectedRevision: number;
            identifier: string;
            properties?: {
              event:
                | "submit_for_review"
                | "approve"
                | "reject"
                | "schedule"
                | "cancel_schedule"
                | "publish"
                | "unpublish"
                | "archive"
                | "restore";
              from_status:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
              occurred_at: string;
              reason?: string;
              to_status:
                | "draft"
                | "review"
                | "approved"
                | "scheduled"
                | "published"
                | "archived";
            };
            relations?: { actor?: string; entry: string };
            title?: string;
          },
          number,
          Name
        >;
      };
    };
  };

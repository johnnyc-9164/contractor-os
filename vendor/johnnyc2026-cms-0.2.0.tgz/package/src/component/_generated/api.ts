/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as calculations from "../calculations.js";
import type * as docValidators from "../docValidators.js";
import type * as pagination from "../pagination.js";
import type * as projections from "../projections.js";
import type * as records_cms_actor from "../records/cms_actor.js";
import type * as records_cms_asset from "../records/cms_asset.js";
import type * as records_cms_asset_variant from "../records/cms_asset_variant.js";
import type * as records_cms_content_entry from "../records/cms_content_entry.js";
import type * as records_cms_content_reference from "../records/cms_content_reference.js";
import type * as records_cms_content_type from "../records/cms_content_type.js";
import type * as records_cms_entry_taxonomy from "../records/cms_entry_taxonomy.js";
import type * as records_cms_field_definition from "../records/cms_field_definition.js";
import type * as records_cms_navigation from "../records/cms_navigation.js";
import type * as records_cms_navigation_item from "../records/cms_navigation_item.js";
import type * as records_cms_publication from "../records/cms_publication.js";
import type * as records_cms_redirect from "../records/cms_redirect.js";
import type * as records_cms_revision from "../records/cms_revision.js";
import type * as records_cms_site from "../records/cms_site.js";
import type * as records_cms_taxonomy from "../records/cms_taxonomy.js";
import type * as records_cms_taxonomy_term from "../records/cms_taxonomy_term.js";
import type * as records_cms_workflow_log from "../records/cms_workflow_log.js";
import type * as relations from "../relations.js";
import type * as scorecards from "../scorecards.js";
import type * as validators from "../validators.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";
import { anyApi, componentsGeneric } from "convex/server";

const fullApi: ApiFromModules<{
  calculations: typeof calculations;
  docValidators: typeof docValidators;
  pagination: typeof pagination;
  projections: typeof projections;
  "records/cms_actor": typeof records_cms_actor;
  "records/cms_asset": typeof records_cms_asset;
  "records/cms_asset_variant": typeof records_cms_asset_variant;
  "records/cms_content_entry": typeof records_cms_content_entry;
  "records/cms_content_reference": typeof records_cms_content_reference;
  "records/cms_content_type": typeof records_cms_content_type;
  "records/cms_entry_taxonomy": typeof records_cms_entry_taxonomy;
  "records/cms_field_definition": typeof records_cms_field_definition;
  "records/cms_navigation": typeof records_cms_navigation;
  "records/cms_navigation_item": typeof records_cms_navigation_item;
  "records/cms_publication": typeof records_cms_publication;
  "records/cms_redirect": typeof records_cms_redirect;
  "records/cms_revision": typeof records_cms_revision;
  "records/cms_site": typeof records_cms_site;
  "records/cms_taxonomy": typeof records_cms_taxonomy;
  "records/cms_taxonomy_term": typeof records_cms_taxonomy_term;
  "records/cms_workflow_log": typeof records_cms_workflow_log;
  relations: typeof relations;
  scorecards: typeof scorecards;
  validators: typeof validators;
}> = anyApi as any;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
> = anyApi as any;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
> = anyApi as any;

export const components = componentsGeneric() as unknown as {};

// Doc + page validators for the 17 cms_* record tables.
// Derived from the canonical schema (src/component/schema.ts): all 17 tables
// share the same stored field set — _id, _creationTime, identifier, title,
// properties, relations, revision, sourceBlueprint, sourceUpdatedAt.
import { v } from "convex/values";
import {
  cmsActorPropertiesValidator,
  cmsActorRelationsValidator,
  cmsAssetPropertiesValidator,
  cmsAssetRelationsValidator,
  cmsAssetVariantPropertiesValidator,
  cmsAssetVariantRelationsValidator,
  cmsContentEntryPropertiesValidator,
  cmsContentEntryRelationsValidator,
  cmsContentReferencePropertiesValidator,
  cmsContentReferenceRelationsValidator,
  cmsContentTypePropertiesValidator,
  cmsContentTypeRelationsValidator,
  cmsEntryTaxonomyPropertiesValidator,
  cmsEntryTaxonomyRelationsValidator,
  cmsFieldDefinitionPropertiesValidator,
  cmsFieldDefinitionRelationsValidator,
  cmsNavigationPropertiesValidator,
  cmsNavigationRelationsValidator,
  cmsNavigationItemPropertiesValidator,
  cmsNavigationItemRelationsValidator,
  cmsPublicationPropertiesValidator,
  cmsPublicationRelationsValidator,
  cmsRedirectPropertiesValidator,
  cmsRedirectRelationsValidator,
  cmsRevisionPropertiesValidator,
  cmsRevisionRelationsValidator,
  cmsSitePropertiesValidator,
  cmsSiteRelationsValidator,
  cmsTaxonomyPropertiesValidator,
  cmsTaxonomyRelationsValidator,
  cmsTaxonomyTermPropertiesValidator,
  cmsTaxonomyTermRelationsValidator,
  cmsWorkflowLogPropertiesValidator,
  cmsWorkflowLogRelationsValidator,
} from "./validators";

export const cmsActorDocValidator = v.object({
  _id: v.id("cms_actor"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsActorPropertiesValidator,
  relations: cmsActorRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsActorPageValidator = v.object({
  page: v.array(cmsActorDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsAssetDocValidator = v.object({
  _id: v.id("cms_asset"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsAssetPropertiesValidator,
  relations: cmsAssetRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsAssetPageValidator = v.object({
  page: v.array(cmsAssetDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsAssetVariantDocValidator = v.object({
  _id: v.id("cms_asset_variant"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsAssetVariantPropertiesValidator,
  relations: cmsAssetVariantRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsAssetVariantPageValidator = v.object({
  page: v.array(cmsAssetVariantDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsContentEntryDocValidator = v.object({
  _id: v.id("cms_content_entry"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsContentEntryPropertiesValidator,
  relations: cmsContentEntryRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsContentEntryPageValidator = v.object({
  page: v.array(cmsContentEntryDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsContentReferenceDocValidator = v.object({
  _id: v.id("cms_content_reference"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsContentReferencePropertiesValidator,
  relations: cmsContentReferenceRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsContentReferencePageValidator = v.object({
  page: v.array(cmsContentReferenceDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsContentTypeDocValidator = v.object({
  _id: v.id("cms_content_type"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsContentTypePropertiesValidator,
  relations: cmsContentTypeRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsContentTypePageValidator = v.object({
  page: v.array(cmsContentTypeDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsEntryTaxonomyDocValidator = v.object({
  _id: v.id("cms_entry_taxonomy"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsEntryTaxonomyPropertiesValidator,
  relations: cmsEntryTaxonomyRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsEntryTaxonomyPageValidator = v.object({
  page: v.array(cmsEntryTaxonomyDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsFieldDefinitionDocValidator = v.object({
  _id: v.id("cms_field_definition"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsFieldDefinitionPropertiesValidator,
  relations: cmsFieldDefinitionRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsFieldDefinitionPageValidator = v.object({
  page: v.array(cmsFieldDefinitionDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsNavigationDocValidator = v.object({
  _id: v.id("cms_navigation"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsNavigationPropertiesValidator,
  relations: cmsNavigationRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsNavigationPageValidator = v.object({
  page: v.array(cmsNavigationDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsNavigationItemDocValidator = v.object({
  _id: v.id("cms_navigation_item"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsNavigationItemPropertiesValidator,
  relations: cmsNavigationItemRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsNavigationItemPageValidator = v.object({
  page: v.array(cmsNavigationItemDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsPublicationDocValidator = v.object({
  _id: v.id("cms_publication"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsPublicationPropertiesValidator,
  relations: cmsPublicationRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsPublicationPageValidator = v.object({
  page: v.array(cmsPublicationDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsRedirectDocValidator = v.object({
  _id: v.id("cms_redirect"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsRedirectPropertiesValidator,
  relations: cmsRedirectRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsRedirectPageValidator = v.object({
  page: v.array(cmsRedirectDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsRevisionDocValidator = v.object({
  _id: v.id("cms_revision"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsRevisionPropertiesValidator,
  relations: cmsRevisionRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsRevisionPageValidator = v.object({
  page: v.array(cmsRevisionDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsSiteDocValidator = v.object({
  _id: v.id("cms_site"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsSitePropertiesValidator,
  relations: cmsSiteRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsSitePageValidator = v.object({
  page: v.array(cmsSiteDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsTaxonomyDocValidator = v.object({
  _id: v.id("cms_taxonomy"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsTaxonomyPropertiesValidator,
  relations: cmsTaxonomyRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsTaxonomyPageValidator = v.object({
  page: v.array(cmsTaxonomyDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsTaxonomyTermDocValidator = v.object({
  _id: v.id("cms_taxonomy_term"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsTaxonomyTermPropertiesValidator,
  relations: cmsTaxonomyTermRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsTaxonomyTermPageValidator = v.object({
  page: v.array(cmsTaxonomyTermDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

export const cmsWorkflowLogDocValidator = v.object({
  _id: v.id("cms_workflow_log"),
  _creationTime: v.number(),
  identifier: v.string(),
  title: v.optional(v.string()),
  properties: cmsWorkflowLogPropertiesValidator,
  relations: cmsWorkflowLogRelationsValidator,
  revision: v.number(),
  sourceBlueprint: v.string(),
  sourceUpdatedAt: v.optional(v.string()),
});

export const cmsWorkflowLogPageValidator = v.object({
  page: v.array(cmsWorkflowLogDocValidator),
  isDone: v.boolean(),
  continueCursor: v.union(v.string(), v.null()),
});

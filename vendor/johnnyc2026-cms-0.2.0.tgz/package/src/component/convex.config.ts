// GENERATED — component registration. Mount from the host app:
//   import { defineApp } from "convex/server";
//   import cms from "../components/cms/src/component/convex.config";
//   const app = defineApp();
//   app.use(cms);
//   export default app;
import { defineComponent } from "convex/server";

export default defineComponent("cms");

// No scorecards are defined on any cms_* blueprint in the Port source.
// Per the skill contract, executable predicates are generated only when rule
// queries exist — otherwise this module reports definition_missing.
export const CMS_SCORECARDS = "definition_missing" as const;
export type CmsScorecards = typeof CMS_SCORECARDS;

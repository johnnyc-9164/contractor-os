// GENERATED — deterministic calculations compiled from Port JQ formulas.
// Original formula is preserved in a comment above each function.
// JQ parity fixtures live in tests/parity.mjs (run against the jq binary).
import type { Infer } from "convex/values";
import type {
  cmsActorPropertiesValidator,
  cmsAssetPropertiesValidator,
  cmsAssetRelationsValidator,
  cmsContentEntryPropertiesValidator,
  cmsContentEntryRelationsValidator,
  cmsNavigationItemPropertiesValidator,
  cmsNavigationItemRelationsValidator,
  cmsPublicationPropertiesValidator,
  cmsPublicationRelationsValidator,
  cmsRevisionPropertiesValidator,
  cmsRevisionRelationsValidator,
  cmsWorkflowLogPropertiesValidator,
  cmsWorkflowLogRelationsValidator,
} from "./validators";

// Port formula (cms_actor.full_name): .properties.display_name
// language: jq, declared return: string
export function cmsActor_full_name(props: Infer<typeof cmsActorPropertiesValidator>): unknown {
  return props.display_name ?? null;
}

// Port formula (cms_asset.is_deleted): .properties.deleted_at != null
// language: jq, declared return: boolean
export function cmsAsset_is_deleted(props: Infer<typeof cmsAssetPropertiesValidator>): unknown {
  return props.deleted_at != null;
}

// Port formula (cms_asset.size_kb): (.properties.size_bytes // 0) / 1024
// language: jq, declared return: number
export function cmsAsset_size_kb(props: Infer<typeof cmsAssetPropertiesValidator>): unknown {
  return (props.size_bytes ?? 0) / 1024;
}

// Port formula (cms_content_entry.is_live): .properties.status == "published"
// language: jq, declared return: boolean
export function cmsContentEntry_is_live(props: Infer<typeof cmsContentEntryPropertiesValidator>): unknown {
  return props.status === "published";
}

// Port formula (cms_content_entry.is_overdue_schedule): .properties.scheduled_publish_at != null and .properties.status == "scheduled"
// language: jq, declared return: boolean
export function cmsContentEntry_is_overdue_schedule(props: Infer<typeof cmsContentEntryPropertiesValidator>): unknown {
  return props.scheduled_publish_at != null && props.status === "scheduled";
}

// Port formula (cms_navigation_item.depth_indicator): .relations.parent_item != null
// language: jq, declared return: boolean
export function cmsNavigationItem_depth_indicator(props: Infer<typeof cmsNavigationItemPropertiesValidator>, relations: Infer<typeof cmsNavigationItemRelationsValidator>): unknown {
  return relations.parent_item != null;
}

// Port formula (cms_publication.publication_label): .properties.action + " @ v" + (.properties.revision_number | tostring)
// language: jq, declared return: string
export function cmsPublication_publication_label(props: Infer<typeof cmsPublicationPropertiesValidator>): unknown {
  return `${props.action ?? ""} @ v${props.revision_number == null ? "null" : String(props.revision_number)}`;
}

// Port formula (cms_revision.revision_label): "v" + (.properties.revision_number | tostring)
// language: jq, declared return: string
export function cmsRevision_revision_label(props: Infer<typeof cmsRevisionPropertiesValidator>): unknown {
  return `v${props.revision_number == null ? "null" : String(props.revision_number)}`;
}

// Port formula (cms_workflow_log.transition_label): .properties.from_status + " → " + .properties.to_status
// language: jq, declared return: string
export function cmsWorkflowLog_transition_label(props: Infer<typeof cmsWorkflowLogPropertiesValidator>): unknown {
  return `${props.from_status ?? ""} \u2192 ${props.to_status ?? ""}`;
}


// GENERATED — relation metadata + read-time helpers.
import type { GenericDatabaseReader } from "convex/server";
type DatabaseReader = GenericDatabaseReader<any>;
import type { GenericId } from "convex/values";

export type RelationMeta = { sourceId: string; target: string; many: boolean; required: boolean };

export const CMS_RELATIONS: Record<string, Record<string, RelationMeta>> = {
  cms_actor: {
  },
  cms_asset: {
    site: { sourceId: "cms_asset.site", target: "cms_site", many: false, required: false },
    uploaded_by: { sourceId: "cms_asset.uploaded_by", target: "cms_actor", many: false, required: false },
  },
  cms_asset_variant: {
    asset: { sourceId: "cms_asset_variant.asset", target: "cms_asset", many: false, required: true },
  },
  cms_content_entry: {
    author: { sourceId: "cms_content_entry.author", target: "cms_actor", many: false, required: false },
    site: { sourceId: "cms_content_entry.site", target: "cms_site", many: false, required: true },
    content_type: { sourceId: "cms_content_entry.content_type", target: "cms_content_type", many: false, required: true },
    last_editor: { sourceId: "cms_content_entry.last_editor", target: "cms_actor", many: false, required: false },
  },
  cms_content_reference: {
    source_entry: { sourceId: "cms_content_reference.source_entry", target: "cms_content_entry", many: false, required: true },
    target_asset: { sourceId: "cms_content_reference.target_asset", target: "cms_asset", many: false, required: false },
    target_entry: { sourceId: "cms_content_reference.target_entry", target: "cms_content_entry", many: false, required: false },
  },
  cms_content_type: {
    site: { sourceId: "cms_content_type.site", target: "cms_site", many: false, required: false },
  },
  cms_entry_taxonomy: {
    entry: { sourceId: "cms_entry_taxonomy.entry", target: "cms_content_entry", many: false, required: true },
    term: { sourceId: "cms_entry_taxonomy.term", target: "cms_taxonomy_term", many: false, required: true },
    assigned_by: { sourceId: "cms_entry_taxonomy.assigned_by", target: "cms_actor", many: false, required: false },
  },
  cms_field_definition: {
    content_type: { sourceId: "cms_field_definition.content_type", target: "cms_content_type", many: false, required: true },
  },
  cms_navigation: {
    site: { sourceId: "cms_navigation.site", target: "cms_site", many: false, required: true },
  },
  cms_navigation_item: {
    navigation: { sourceId: "cms_navigation_item.navigation", target: "cms_navigation", many: false, required: true },
    entry: { sourceId: "cms_navigation_item.entry", target: "cms_content_entry", many: false, required: false },
    parent_item: { sourceId: "cms_navigation_item.parent_item", target: "cms_navigation_item", many: false, required: false },
  },
  cms_publication: {
    published_by: { sourceId: "cms_publication.published_by", target: "cms_actor", many: false, required: false },
    entry: { sourceId: "cms_publication.entry", target: "cms_content_entry", many: false, required: true },
    site: { sourceId: "cms_publication.site", target: "cms_site", many: false, required: true },
    previous_revision: { sourceId: "cms_publication.previous_revision", target: "cms_revision", many: false, required: false },
    revision: { sourceId: "cms_publication.revision", target: "cms_revision", many: false, required: true },
  },
  cms_redirect: {
    site: { sourceId: "cms_redirect.site", target: "cms_site", many: false, required: true },
  },
  cms_revision: {
    entry: { sourceId: "cms_revision.entry", target: "cms_content_entry", many: false, required: true },
    author: { sourceId: "cms_revision.author", target: "cms_actor", many: false, required: false },
  },
  cms_site: {
  },
  cms_taxonomy: {
    site: { sourceId: "cms_taxonomy.site", target: "cms_site", many: false, required: false },
  },
  cms_taxonomy_term: {
    parent: { sourceId: "cms_taxonomy_term.parent", target: "cms_taxonomy_term", many: false, required: false },
    taxonomy: { sourceId: "cms_taxonomy_term.taxonomy", target: "cms_taxonomy", many: false, required: true },
  },
  cms_workflow_log: {
    actor: { sourceId: "cms_workflow_log.actor", target: "cms_actor", many: false, required: false },
    entry: { sourceId: "cms_workflow_log.entry", target: "cms_content_entry", many: false, required: true },
  },
};

export type RelationResolution =
  | { status: "resolved"; doc: unknown }
  | { status: "unresolved"; reason: string };

export async function resolveRelation(
  db: DatabaseReader,
  table: string,
  relation: string,
  id: GenericId<string> | null | undefined,
): Promise<RelationResolution> {
  if (id === null || id === undefined)
    return { status: "unresolved", reason: `relation ${table}.${relation} is empty` };
  const meta = CMS_RELATIONS[table]?.[relation];
  if (!meta) return { status: "unresolved", reason: `unknown relation ${table}.${relation}` };
  const doc = await db.get(id);
  if (!doc) return { status: "unresolved", reason: `target ${meta.target} doc not found` };
  return { status: "resolved", doc };
}

// GENERATED — read-time projections for mirrors and aggregations.
// Mirrors resolve through declared relation paths; missing targets
// return explicit unresolved status, never invented values.
// Aggregations are bounded indexed counts; over-limit returns incomplete.
import type { GenericDatabaseReader } from "convex/server";
type DatabaseReader = GenericDatabaseReader<any>;
import { CMS_RELATIONS } from "./relations";

export type ProjectionResult =
  | { status: "resolved"; value: unknown }
  | { status: "unresolved"; reason: string }
  | { status: "incomplete"; reason: string; partial?: unknown };

const MIRRORS: Record<string, Record<string, string[]>> = {
  cms_asset_variant: {
    asset_filename: ["asset", "filename"],
    asset_type: ["asset", "asset_type"],
  },
  cms_content_entry: {
    content_type_name: ["content_type", "name"],
    site_name: ["site", "name"],
  },
  cms_content_reference: {
    source_entry_title: ["source_entry", "title"],
    source_entry_slug: ["source_entry", "slug"],
    source_content_type_key: ["source_entry", "content_type_key"],
    target_entry_title: ["target_entry", "title"],
    target_asset_filename: ["target_asset", "filename"],
  },
  cms_content_type: {
    site_key: ["site", "key"],
  },
  cms_entry_taxonomy: {
    entry_slug: ["entry", "slug"],
    entry_status: ["entry", "status"],
    entry_title: ["entry", "title"],
    term_name: ["term", "name"],
    term_slug: ["term", "slug"],
  },
  cms_field_definition: {
    content_type_key: ["content_type", "key"],
    site_name: ["content_type", "site", "name"],
  },
  cms_navigation: {
    site_name: ["site", "name"],
  },
  cms_navigation_item: {
    navigation_key: ["navigation", "key"],
    navigation_name: ["navigation", "name"],
    entry_title: ["entry", "title"],
    entry_status: ["entry", "status"],
  },
  cms_publication: {
    entry_title: ["entry", "title"],
    entry_slug: ["entry", "slug"],
    content_type_key: ["entry", "content_type_key"],
    site_key: ["site", "key"],
    publisher_name: ["published_by", "display_name"],
    publisher_email: ["published_by", "email"],
  },
  cms_redirect: {
    site_key: ["site", "key"],
  },
  cms_revision: {
    entry_title: ["entry", "title"],
    entry_slug: ["entry", "slug"],
    content_type_key: ["entry", "content_type_key"],
  },
  cms_taxonomy_term: {
    taxonomy_key: ["taxonomy", "key"],
    taxonomy_name: ["taxonomy", "name"],
  },
  cms_workflow_log: {
    entry_title: ["entry", "title"],
    entry_slug: ["entry", "slug"],
    content_type_key: ["entry", "content_type_key"],
    actor_name: ["actor", "display_name"],
    actor_email: ["actor", "email"],
  },
};

export async function resolveMirror(
  db: DatabaseReader,
  table: string,
  row: { relations: Record<string, any>; properties: Record<string, any> },
  mirrorId: string,
): Promise<ProjectionResult> {
  const path = MIRRORS[table]?.[mirrorId];
  if (!path) return { status: "unresolved", reason: `unknown mirror ${table}.${mirrorId}` };
  // Multi-hop: every segment except the last is a relation id (or an
  // object-valued property to descend into); the last segment is read
  // from the final properties object.
  let current: any = row;
  let currentTable = table;
  for (let i = 0; i < path.length - 1; i++) {
    const seg = path[i];
    if (seg === undefined)
      return { status: "unresolved", reason: "empty mirror path segment" };
    const meta = CMS_RELATIONS[currentTable]?.[seg];
    if (meta) {
      const targetId = current.relations?.[seg];
      if (targetId === null || targetId === undefined)
        return { status: "unresolved", reason: `relation ${currentTable}.${seg} is empty` };
      const doc = await db.get(targetId);
      if (!doc) return { status: "unresolved", reason: `target ${meta.target} doc not found` };
      current = doc;
      currentTable = meta.target;
    } else {
      const val = current.properties?.[seg];
      if (val === null || val === undefined || typeof val !== "object" || Array.isArray(val))
        return { status: "unresolved", reason: `mirror path segment ${seg} is not traversable` };
      current = { properties: val, relations: {} };
    }
  }
  const last = path[path.length - 1];
  if (last === undefined) return { status: "unresolved", reason: "empty mirror path" };
  const value = current.properties?.[last];
  if (value === undefined)
    return { status: "unresolved", reason: `mirror path ${path.join(".")} has no value` };
  return { status: "resolved", value };
}

const AGGREGATIONS: Record<string, Record<string, { target: string; backRelation: string; fn: string }>> = {
  cms_asset: {
    variant_count: { target: "cms_asset_variant", backRelation: "asset", fn: "count" },
  },
  cms_content_entry: {
    publication_count: { target: "cms_publication", backRelation: "entry", fn: "count" },
    revision_count: { target: "cms_revision", backRelation: "entry", fn: "count" },
  },
  cms_content_type: {
    entry_count: { target: "cms_content_entry", backRelation: "content_type", fn: "count" },
    field_count: { target: "cms_field_definition", backRelation: "content_type", fn: "count" },
  },
  cms_navigation: {
    item_count: { target: "cms_navigation_item", backRelation: "navigation", fn: "count" },
  },
  cms_taxonomy: {
    term_count: { target: "cms_taxonomy_term", backRelation: "taxonomy", fn: "count" },
  },
};

const AGGREGATION_LIMIT = 10000;

export async function resolveAggregation(
  db: DatabaseReader,
  table: string,
  row: { _id: unknown },
  aggregationId: string,
): Promise<ProjectionResult> {
  const agg = AGGREGATIONS[table]?.[aggregationId];
  if (!agg) return { status: "unresolved", reason: `unknown aggregation ${table}.${aggregationId}` };
  if (!agg.backRelation)
    return { status: "incomplete", reason: "no deterministic reverse-relation path in source" };
  if (agg.fn !== "count")
    return { status: "incomplete", reason: `aggregation fn ${agg.fn} not compiled` };
  const rows = await (db as any)
    .query(agg.target)
    .withIndex(`by_${agg.backRelation}`, (q: any) => q.eq(`relations.${agg.backRelation}`, row._id))
    .take(AGGREGATION_LIMIT + 1);
  if (rows.length > AGGREGATION_LIMIT)
    return { status: "incomplete", reason: `more than ${AGGREGATION_LIMIT} related rows; bounded count refused`, partial: AGGREGATION_LIMIT };
  return { status: "resolved", value: rows.length };
}

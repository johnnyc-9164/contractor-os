// GENERATED — shared cursor pagination for the cms Convex component.
// Do not hand-edit. Regenerate with the port-to-convex-component skill.
//
// Convex's `.paginate()` is only available in the app runtime; component
// queries must paginate by hand. This keeps the same args shape
// (`paginationOptsValidator`: { numItems, cursor }) and the same return
// shape ({ page, isDone, continueCursor }) as `.paginate()`, so
// `usePaginatedQuery` and existing callers keep working.
import type { PaginationOptions } from "convex/server";

export type ComponentPage<T> = {
  page: T[];
  isDone: boolean;
  continueCursor: string | null;
};

function encodeCursor(parts: Array<string | number>): string {
  return parts.map((p) => String(p)).join(":");
}

/**
 * Keyset pagination over a component-side query.
 *
 * Convex appends `_creationTime` as the final column of every database index,
 * so a plain table scan (the built-in `by_creation_time` index) and an index
 * query built with `.withIndex(...)` both return rows in ascending
 * `_creationTime` order once the leading index key is fixed. Relation-filtered
 * lists always constrain the index key with an equality, so every row on the
 * page shares it; ties on `_creationTime` are broken by `_id`.
 *
 * The cursor is "<creationTime>:<id>" and the resume filter restarts strictly
 * after the last returned document, so rows are never skipped or repeated.
 *
 * `indexMode` is accepted for compatibility with generated callers; both
 * modes use the same (_creationTime, _id) keyset described above.
 */
export async function paginateComponentQuery<
  T extends { _id: string; _creationTime: number },
>(opts: {
  baseQuery: any;
  paginationOpts: PaginationOptions;
  // Retained for compatibility with generated callers; no longer changes behavior.
  indexMode?: boolean;
}): Promise<ComponentPage<T>> {
  const { numItems, cursor } = opts.paginationOpts;
  let q = opts.baseQuery.order("asc");
  if (cursor) {
    const parts = cursor.split(":");
    const t = Number(parts[0]);
    const lastId = parts[1] as string;
    q = q.filter((f: any) =>
      f.or(
        f.gt(f.field("_creationTime"), t),
        f.and(f.eq(f.field("_creationTime"), t), f.gt(f.field("_id"), lastId)),
      ),
    );
  }
  const rows = (await q.take(numItems + 1)) as T[];
  const hasMore = rows.length > numItems;
  const page = hasMore ? rows.slice(0, numItems) : rows;
  const last = page[page.length - 1];
  const continueCursor =
    hasMore && last ? encodeCursor([last._creationTime, last._id]) : null;
  return { page, isDone: !hasMore, continueCursor };
}

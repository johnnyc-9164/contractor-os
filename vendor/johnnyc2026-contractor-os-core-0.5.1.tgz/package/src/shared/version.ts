/** Package/runtime compatibility constants. Keep these synchronized with package.json and migration docs. */
export const CONTRACTOR_OS_COMPONENT = 'contractorOs' as const;
export const CONTRACTOR_OS_VERSION = '0.5.1' as const;
/** Schema remains data-compatible with v0.4.0; v0.5 hardens the component/package boundary. */
export const CONTRACTOR_OS_SCHEMA_VERSION = '0.4.0' as const;
export const CONTRACTOR_OS_CAPABILITIES = Object.freeze([
  'typed_records',
  'transactional_business_commands',
  'immutable_domain_events',
  'tenant_scoped_reads',
  'idempotent_requests',
  'optimistic_revisions',
  'derived_projections',
  'component_compatible_pagination',
] as const);
